#Fred, ou la Légende de Malaxar

import copy
from random import randint
from lieux import *
from combat import *
import save

########### FONCTIONS ###########
SAVE = None # initialisée plus tard, en début de jeu

def saveone(key, true_value):
    SAVE.setItem(key, save.encode(true_value))

def getone(key):
    return save.decode(SAVE.getItem(key))

def stay(text: str):
    input(text + "\n")

def alpha_liste(n: int):
    assert (n>=0)
    alph = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    return [alph[i] for i in range(n)]

def print_tuto():
    print("> Pour sortir de la pièce où tu te trouves, écris 'sortir'.")
    print("> Pour entrer dans une pièce ou aller dans un lieu adjacent,\n  écris 'aller [nom de la pièce / du lieu]' ou 'aller [chiffre / lettre correspondant(e)]'.")
    print("> Pour faire quelque chose dans la liste de choses à faire, écris 'faire [indice correspondant]'.")
    print("> Pour connaître tes statistiques et voir ton sac, écris 'stats'.")
    print("> Pour danser, écris 'danser'.")
    print("> Pour relire ces instructions, écris 'aide' ou 'help'.")
    print("> (Commandes non sensibles à la case.)")
    print("> Tes progrès sont enregistrés automatiquement.")

def command():
    COM = input("Que fais-tu ? ").lower().strip(" ")
    print()

    if COM in ("aide", "help"):
        print_tuto()

    elif COM == "mourir":
        print("Non.")

    elif len(COM) == 0:
        COM = "kufyhgfndm"

    return COM

def clean(liste, para = ""):
    return [e for e in liste if e != para]

def print_liste(options):
    for i, o in enumerate(options):
        print(f"\t{i+1}.", o)
    print()

########### MAP ###########
NoPiece = piece("Aucune", {})

# fort Loprex - la tour
tf_pieces = [chambre_Fred := piece("Chambre de Fred", {"Faire une peinture": {"print": "Tu fais une jolie peinture de ton village. Chaque fois tu la fais mieux !"}, "Écrire": {"print": "Tu écris à propos de toi, de ton village et de Lord Loprex. Rien de nouveau..."}, "Penser": {"print": "Tu vis dans la joie et dans un beau village. Mais...\nQui es-tu ? Où es-tu ? Qu'est-ce que la vie ? Quelle place y as-tu ?"}}),
             chambre_Loprex := piece("Chambre de Loprex", {}, "La chambre de ton père, ton créateur"),
             bureau_Loprex := piece("Bureau de Loprex", {"Demander à ton père ce que tu dois faire": {"print": "Loprex : Fais ce qui te plais dans ce monde merveilleux !", "return": "papa1"}, "Demander à ton père qui tu es": {"print": "Tu es mon enfant chéri et je t'aime beaucoup.", "return": "papa2"}}),
             atelier := piece("Atelier", {}, "Il y a une grande table au milieu de la pièce; tu es né là-dessus.")]
tour_fort = lieu("LA TOUR DU FORT LOPREX", tf_pieces, "Des étandards rouges reposent sur les murs. Ils portent le symbole de Loprex : un triangle dont l'une des pointes est dans un cercle.")
tour_fort.init_pieces()

# fort Loprex - village
Pain = Objet("Pain", "heal 15", "Récupère 15 PV")
vf_pieces = [boulangerie := piece("Boulangerie", {"Demander du pain": {"print": "Boulanger : Voici du pain pour toi, cher Fred !", "pickup": Pain}}, "Du pain !"),
             magasin := piece("Magasin", {"Demander ce qu'il y a": {"print": "Vendeuse : Tu as déjà tout ce qu'il te faut, cher Fred !"}}),
             taverne := piece("Taverne", {"Dire bonjour": {"print": "Villageois : Ah, voici cher Fred !"}}),
             tour_de_garde := piece("Tour de garde", {}, ouvert = False),
             portal := piece("Grand portail", {"Sortir du fort": {"return": "leave_fort", "print": "Tu es sorti du fort Loprex.\n"}}, "La seule connexion avec l'extérieur...", ouvert = False)]
village_fort = lieu("VILLAGE DU FORT LOPREX", vf_pieces, "Un village joyeux !")
village_fort.init_pieces()

def add_murailles_doute():
    boulangerie.add_action("Demander ce qu'il y a derrière les murailles", {"print": "Boulanger : Veux-tu du pain, cher Fred ?"})
    magasin.add_action("Demander ce qu'il y a derrière les murailles", {"print": "Vendeuse : Ah... Je ne sais pas, cher Fred."})
    taverne.add_action("Demander ce qu'il y a derrière les murailles", {"print": "Villageois : Ha ! Mais quelle question ! As-tu même besoin de t'en poser, cher Fred ?"})

connect(tour_fort, village_fort)

# plaines pâles (AKA "???")
hors_fort = piece("Quelque part...", {"Avancer": {"print": "Tu marches.", "return": "add_walk"}}, "Une plaine énorme s'étend sans fin devant toi. L'herbe pâle, presque transparente, danse lentement au rythme d'une légère brise.\nLes nuages s'étendent jusqu'à l'horizon.\nCela ne ressemble pas à l'enfer décrit par ton père...", ouvert = False)
plaines_pales = lieu("???", [hors_fort])
plaines_pales.init_pieces()

# Ajxu
ElectroJus = Objet("Electro Jus", "mana 2", "Gagne 2 points de mana")
ajxu_pieces = [hotel := piece("Hotel", {"Dire bonjour": {"print": "Ajan : Bonjour Fred. Comment vas-tu ?"}}, "Là où tous les voyageurs se reposent."),
               chez_domila := piece("Chez Domila", {"Dire bonjour": {"print": "Domila : Salut, Fred ! Ta journée se passe bien ?"}}, "Domila est ton meilleur ami et il t'accueille chez lui."),
               temple := piece("Temple de la Lueur de la Lune", {"Dire bonjour": {"print": "Goday : Bonjour Fred, que Malaxar t'illumine. As-tu des questions ?", "return": "temple_bonjour"}}, "Un endroit pour s'illuminer."),
               fight_club := piece("Club de combat", {"Dire bonjour": {"print": "Un robot sort par une porte.\nLe robot : Oh ! Une autre machine qui marche ! Enchanté de te connaître !\nLe robot : Moi je suis Electro Jake, et j'enseigne aux villageois à se battre.\nElectro Jake : Alors, tu veux apprendre ?", "return": "combat_club_bonjour"}}),
               salle_reunion := piece("Salle de reunion", {"Dire bonjour": {"print": "Des villageois réunis : Bonjour Fred !"}}, "Là où se font toutes sortes de rencontres.")]
Ajxu = lieu("AJXU", ajxu_pieces)
Ajxu.init_pieces()

# Le port
Huile = Objet("Huile magique", "heal 50", "Récupère 50 PV")
port_pieces = [marche := piece("Marche", {"Demander à propos de Coubeau et Zadriel": {"print": "Villageois : Ah, oui ! Ils sont bien connus, mais non pas pour les mêmes raisons.\nVillageois : Kapitaine Coupbeau est un protecteur des Mers, un sauveur !\nVillageois : Quant au Kapitaine Zadriel, même s'il est aussi un protecteur, il est réputé pour être violent et toujours en colère.\nVillageois : Pour les trouver, il faut partir loin dans la mer...!", "return": "ask_Kaps"}, "Acheter de l'huile": {"pickup": Huile, "return": "achat_huile"}}),
               quai := piece("Quai", {}, "Là où reposent les bateaux.")]
Port = lieu("PORT", port_pieces, "Un village au bord de la mer sentant le poisson et le sel. L'horizon bleu reste insondable.")
Port.init_pieces()

# Les Mers
mers_pieces = [bateauCoupbeau := piece("Navire de Coupbeau", {"Parler à Coupbeau": {"print": "Coupbeau lance des ordres de part et d'autre.\nMalgré sa situation bellique, il inspire du courage et une certaine bonne humeur.\nTu lui expliques que le Kapitaine Zadriel n'est pas un criminel, mais un bienfaiteur avec une mauvaise réputation.\nTu lui propose alors d'arrêter le feu.\nCoupbeau : Je veux bien te croire. Si tu parviens à le convaincre de cesser son feu, nous travaillerons ensemble dorénavant !"}}),
               bateauZadriel := piece("Navire de Zadriel", {"Parler à Zadriel": {"print": "Zadriel vocifère des ordres de partout et déborde avec de la colère, en montrant ses dents pointues à Coupbeau.\nSa tête est couverte de poils noirs, et son menton est long et pointu; il ressemble plus à un monstre qu'à un humain.\nTu tentes de convaincre Zadriel que Coupbeau n'est pas vraiment un ennemi, mais il ne veut rien écouter. Tu insistes, tu lui en supplies.\nFinalement, Zadriel en a marre et ordonne qu'on cesse le feu, avec une certaine intention ironique.\nCoupbeau fait alors la même chose de son côté, de sorte que Zadriel se surprend fortement.", "return": "spoke_Zadriel"}})]
Mers = lieu("LES MERS", mers_pieces, "Sur ta petite barque, tu flottes perdu dans l'immensité bleue.")
Mers.init_pieces()

# Les Plaines
Longue_vue = Objet("Longue-vue abîmée", "special all_allies", "Gagne 1 point de mana. Toute l'équipe gagne 100% de défense.")
def special_longue_vue(ally_team):
    mana_up()
    for m in ally_team:
        m.buff("défense", 1)
Longue_vue.set_special(special_longue_vue)

plaines_pieces = [qqpart := piece("Quelque part", {"Combattre les yeux": {"print": "Vous rencontrez soudainement des yeux étranges qui sortent de la terre.\nIls sont aussi grands que vous et vous fixent de leur regard avide et profond.\nPuis, une bouche aux dents pointues vous attaque !", "return": "fight_eyebunch"}}, "", False),
                  proche_labo := piece("Devant le laboratoire", {"Approcher le laboratoire": {"print": "Vous marchez vers la structure métallique et vous rencontrez un garçon au regard perdu, étendu sur l'herbe.", "return": "meet_Kus"}}),
                  laboratoire := piece("Laboratoire", {"Inspectionner": {"print": "Le site est clairement abandonné. Mais il paraît aussi maltraité : des feuilles et des cahier s'étalent sur le sol,\nles instruments sont renversés ou cassés. Tu prends un cahier un peu abîmé et tu commences à le lire. Il s'agit d'un journal,\nchaque entrée correspond à une étude, à une observation ou à une expérience. Elles terminent toutes par conclure la même chose : Malaxar est incomplet.\nAu fur et à mesure que tu avances les pages, tu constate que la caligraphie devient illisible et même déformée en excès,\net qu'on insiste avec obstination sur l'incomplétitude de Malaxar.\nCertaines pages, pleines de rayures et de tâches, expriment beaucoup de frustration.", "return": "labo_inspect"}}, "Un laboratoire abandonné.", False)]
Plaines = lieu("LES PLAINES", plaines_pieces, "Des étendues vertes à perte de vue, un Soleil convenable.\nEt, au milieu, une infrastructure solitaire...")
Plaines.init_pieces()

# Le Désert
Chapeau_reddition = Objet("Chapeau de la reddition", "special all_enemies", "Étourdit tous tes ennemis.")
def special_chapeau_reddition(enemy_team):
    for m in enemy_team:
        m.set_effect("étourdi", True)
Chapeau_reddition.set_special(special_chapeau_reddition)

desert_pieces = [milieu_desert := piece("Au milieu du desert", {"Explorer": {"return": "desert_door_found"}}),
                 souterrain := piece("Souterrain", {"???": {"return": "meet_Kaer"}}, "Un souterrain en plein milieu du désert. C'est particulièrement humide.", False)]
Desert = lieu("LE DESERT", desert_pieces, "Le désert offre un paysage aride et solitaire. Qu'il y a-t-il donc à voir ici ?")
Desert.init_pieces()

# La Foire - La Foire
Touche_clavecorgue = Objet("Touche de claveçorgue", "special all_allies", "Gagne 1 point de mana. Toute l'équipe gagne 80% de force.")
def special_touche_clavecorgue(ally_team):
    mana_up()
    for m in ally_team:
        m.buff("force", 0.8)
Touche_clavecorgue.set_special(special_touche_clavecorgue)

foire_pieces = [portail_foire := piece("Portail", {"Partir": {"print": "Akordd Keyl: Voyageurs, vous partez bien trop tôt ! Vous n'avez pas assez profité de la Foire !", "return": "tried_escape"}}),
                roue := piece("Roue", {"Faire un tour dans la roue": {"print": "Vous montez dans une cabine et la roue vous mène en haut. Depuis là, vous apercevez les Profondeurs,\nla plus grande chaîne de montagnes de Malaxar. Ses sommets sont toujours couverts par des épais nuages sombres.\nEnsuite, la roue vous descend.", "return": "roue_done"}}),
                cible := piece("Cible", {"Tirer trois fléchettes": {"print": "Vous lancez chacun une fléchette.\nVous râtez tous les trois !", "return": "cible_done"}}, "On vous montre une cible et vous propose de tirer trois fléchettes."),
                carrousel := piece("Carrousel", {"Monter": {"print": "Vous montez sur le carrousel. :D", "return": "carrousel_done"}}, "Des licornes et des grenouilles dorées fixées sur une plateforme tournante."),
                table_carte := piece("Table de jeu", {"Jouer aux cartes": {"print": "Vous rejoignez trois autres personnes pour jouer aux cartes.\nIls tiennent à ne pas vous expliquer les règles, et vous ne comprenez rien. Vous trouvez néanmoins le jeu très amusant.", "return": "cartes_done"}}, "Autour d'une table, plusieurs personnes jouent aux cartes."),
                kebab := piece("Kebab", {"Commander un kébab": {"print": "Zadriel dévore férocement son kébab.\nEn tant que frigo, tu ne peux pas manger...", "return": "eat_kebab"}})]
Foire = lieu("LA FOIRE", foire_pieces, "Une immense foire où des villageois s'amusent sur de nombreuses attractions. Vous entendez une musique de fond joyeuse.")
Foire.init_pieces()

# La Foire - village
village_foire_pieces = [maison1 := piece("Une maison", {"Observer": {"print": "Aucune lumière ne semble venir de l'intérieur. La maison semble abandonnée."}, "Appeler": {"print": "Le silence est la seule réponse que vous obtenez."}}),
                        maison2 := piece("Une autre maison", {"Observer": {"print": "La maison est dans un assez mauvais état. Vous ne percevez aucun signe de vie dans les alentours."}, "Appeler": {"print": "Personne ne vous répond."}}),
                        portail_village := piece("Portail de la Foire", {"Entrer": {"return": "enter_fair"}}, "Un portail imposant et fortement décoré. Des barres métalliques courbées avec style disent \"Foire des cousins Keyl\".")]
village_foire = lieu("VILLAGE DE LA FOIRE", village_foire_pieces, "Un petit village, quelques maisons et des rues désertes...")
village_foire.init_pieces()

# Les Profondeurs
prof_pieces = [vallee := piece("Vallee", {}, "Vous vous trouvez au pied commun de hautes montagnes avec peu de végétation."),
               antre := piece("Antre", {"Explorer l'antre": {"return": "meet_H"}}, "Une grotte sombre et profonde perdue dans les montagnes."),
               sommet := piece("Montagne profonde", {"Monter jusqu'au sommet": {"return": "go_to_Grand_Noyau"}}, "Le sommet de la plus profonde des montagnes pénètre des nuages denses et sombres.", False)]
profondeurs = lieu("LES PROFONDEURS", prof_pieces, "Une chaîne de montagnes dont les sommets les plus hauts sont cachés par des nuages sombres.\nIl y a partout un léger brouillard.")
profondeurs.init_pieces()


liste_lieux = [tour_fort, village_fort, plaines_pales, Ajxu, Port, Mers, Plaines, Desert, Foire, village_foire, profondeurs]

########### PERSONNAGES / STATS ###########
MANA = 0
MAX_MANA = 10
TEAM_FRED = []
ENNEMIS = []
ACTIONS = {}

def mana_up(amount = 1):
    global MANA, MAX_MANA
    MANA += amount
    if MANA > MAX_MANA:
        MANA = MAX_MANA
    if MANA < 0:
        MANA = 0

# abilités d'ElectroJake
def abil_trainer(author, args):
    global MANA, MAX_MANA

    # args == []
    mana_up(MAX_MANA)
    print(author.nom, f"augmente ton mana de {MAX_MANA}.")
    author.heal(author.maxPV)

def plasma_shot(author, args):
    t_enemy = args[0]
    author.buff("force", 1)
    t_enemy.reset_shield()
    print(f"{t_enemy.nom} perd tout son bouclier !")
    author.attack(t_enemy)

def auto_fix(author, args):
    # args == []
    author.heal(author.defense * author.def_mod)
    author.defend(0.5)

# abilités de Fred
def cultiver(author, args):
    t_ally = args[0]
    t_ally.buff("force", 0.2*(1 + MANA))
    author.defend(0.75)

def conviction(author, args):
    # args == []
    for m in TEAM_FRED:
        m.defend()

def vita_fonda(author, args):
    # args == []
    for m in TEAM_FRED:
        if m.PV > 0:
            m.heal(10*MANA)

# abilités de Coupbeau
def force_conf(author, args):
    # args == []
    for m in TEAM_FRED:
        if m.PV > 0:
            m.buff("défense", 0.5)
            m.buff("force", 0.5)

# abilités de Zadriel
def force_rage(author, args):
    t_enemy = args[0]
    author.buff("force", 1)
    author.attack(t_enemy)

# abilités d'Oeil d'Hypsiloxis
def hypnose(author, args):
    t_enemy = args[0]
    if t_enemy != None:
        t_enemy.increase_effect("hypnose")
        if t_enemy.get_effect("hypnose") % 2 == 0:
            t_enemy.set_effect("étourdi", True)
            print(author.nom, "hypnotise", t_enemy.nom, "!")
        else:
            print(author.nom, "tente d'hypnotiser", t_enemy.nom + ".")

def drenage(author, args):
    t_enemy = args[0]
    n = t_enemy.get_effect("hypnose")
    if n == None:
        n = 0
    mana_up(-n)
    t_enemy.set_effect("hypnose", 0)
    print(author.nom, f"réduit ton mana de {n} !")

# abilités de Bouche d'Hypsiloxis
def morsure(author, args):
    t_enemy = args[0]
    if t_enemy != None:
        n = t_enemy.get_effect("hypnose")
        author.buff("force", 0.15*n)
        author.attack(t_enemy)

def deplacement_sur(author, args):
    # args == []
    count = 0
    for m in ENNEMIS:
        if m.nom == "Bouche d'Hypsiloxis" and m.PV > 0:
            count += 1
    
    for m in ENNEMIS:
        m.defend(0.5*count)

# abilités de Kus Omniplex
def tout_detruire(author, args):
    # args == []
    for m in TEAM_FRED:
        if m.PV > 0:
            author.attack(m, 0.75)

# abilités de Käer
def contre_coup(author, args):
    # args == []
    author.defend()
    author.set_effect("contre-coup", True)

# abilités de Fred spectre
def motiver(author, args):
    # args == []
    mana_up()

# abilités de Markatt Keyl
def enchainer(author, args):
    t_enemy_1 = args[0]
    t_enemy_2 = args[1]
    author.attack(t_enemy_1)
    if t_enemy_2 != None:
        author.attack(t_enemy_2)

def fire_symphony(author, args):
    # args == []
    print("Markatt crache furieusement des colonnes de flammes par ses tubes.")
    print("Markatt")
    for m in TEAM_FRED:
        if m.PV > 0:
            author.attack(m)

# abilités d'Akordd Keyl
def seduire(author, args):
    # args == []
    for m in TEAM_FRED:
        if m.PV > 0:
            m.buff("force", -0.2)

# abilités de Garde de Loprex
def choc_electrique(author, args):
    t_enemy = args[0]
    if t_enemy != None:
        author.attack(t_enemy)
        print(author.nom, "électrocute", t_enemy.nom + ".")
        t_enemy.increase_effect("électrocution")
        t_enemy.buff("force", -t_enemy.get_effect("électrocution")/10)
        t_enemy.buff("défense", -t_enemy.get_effect("électrocution")/10)

#abilités de Sir Loprex
def surcharge(author, args):
    # args == []
    author.set_effect("surcharge", True)

def chatiment(author, args):
    global TEAM_FRED

    # args == []
    for m in TEAM_FRED:
        if m.PV > 0:
            author.buff("force", m.get_effect("électrocution")/10)
            author.attack(m)

def allumer(author, args):
    if (t_enemy := args[0]) != None:
        t_enemy.set_effect("surcharge", True)
        author.attack(t_enemy)

Fred = Char("Fred", 100, 15, 25, ["skip"])

# abilité de Fred
def etre(author, args):
    global Fred

    # agrs == []
    stay("\nTu comprends que ce que tu as face à toi n'est pas un ennemi.")
    stay("Il s'agit de toi-même.")
    stay("Tu baisse ton arme et tu te rapproches de ta copie.\nLentement, comme à travers un miroir, tu la traverses. Tu sens les deux entités s'unir en un seul Fred.")
    Fred.set_effect("final_win", True)

Coupbeau = Char("Kap. Coupbeau", 175, 20, 20)
Coupbeau.add_ability(Ability("Force de confiance", 5, [], force_conf, "Toute l'équipe gagne 50% de force et 50% de défense."))

Zadriel = Char("Kap. Zadriel", 175, 25, 15)
Zadriel.add_ability(Ability("Force de rage", 4, ["target_enemy"], force_rage, "Gagne 100% de force. Attaque."))

# abilité des Kapitaines
def acte_kap(author, args):
    global Zadriel, Coupbeau, ACTIONS

    t_enemy = args[0]
    print(f"Les Kapitaines Coupbeau et Zadriel se synchronisent et appliquent un seul grand coup sur {t_enemy.nom} qui le fait reculer.")
    if author.nom == Coupbeau.nom:
        Coupbeau.buff("force", 1.0)
        Zadriel.buff("force", 1.0)
        Coupbeau.attack(t_enemy)
        Zadriel.attack(t_enemy)
    elif author.nom == Zadriel.nom:
        Zadriel.buff("force", 1.0)
        Coupbeau.buff("force", 1.0)
        Zadriel.attack(t_enemy)
        Coupbeau.attack(t_enemy)
    else:
        raise Exception("wtf? who are you?")
    t_enemy.set_effect("étourdi", True)
    ACTIONS[Coupbeau] = "ability"
    ACTIONS[Zadriel] = "ability"

acte_du_kap = Ability("Acte du Kapitaine", 6, ["target_enemy"], acte_kap, "Coupbeau et Zadriel gagnent 100% de force puis attaquent un unique ennemi. Celui-ci devient étourdi.")
Coupbeau.add_ability(acte_du_kap)
Zadriel.add_ability(acte_du_kap)

ElectroJake = Char("Electro Jake", 100, 20, 15, ["defend", "attack #1_enemy"])

Hyps_Eye = Char("Oeil d'Hypsiloxis", 115, 10, 30, ["ability Hypnose random_enemy"]*5 + ["ability Drénage-d-énergie highestHypnose_enemy"])
Hyps_Eye.add_ability(Ability("Hypnose", 0, ["random_enemy"], hypnose))
Hyps_Eye.add_ability(Ability("Drénage-d-énergie", 0, ["highestHypnose_enemy"], drenage))
Hyps_Eye2 = copy.deepcopy(Hyps_Eye)

Hyps_Mouth = Char("Bouche d'Hypsiloxis", 170, 30, 30, ["attack random_enemy", "attack random_enemy", "ability Morsure-de-conscience highestHypnose_enemy", "attack random_enemy", "ability Morsure-de-conscience highestHypnose_enemy", "ability Déplacement-sûr"])
Hyps_Mouth.add_ability(Ability("Morsure-de-conscience", 0, ["highestHypnose_enemy"], morsure))
Hyps_Mouth.add_ability(Ability("Déplacement-sûr", 0, [], deplacement_sur))

Kus = Char("Kus Omniplex", 400, 50, 25, ["attack random_enemy", "attack random_enemy", "ability Tout-détruire", "defend"])
Kus.add_ability(Ability("Tout-détruire", 0, [], tout_detruire, "", "Kus : Chaos, chaos, chaos ! Vous mourrez tous ! HIHIHIHAHA !"))

Fred_spectre = Char("Fred (spectre)", 0, 0, 0, spectre = True)
Fred_spectre.add_ability(Ability("Motiver", 0, [], motiver, "Gagne 1 point de mana."))

Kaer = Char("Kap. Käer", 300, 60, 45, ["ability Contre-coup", "ability Contre-coup", "ability Absorber-vie random_enemy"])
Kaer.add_ability(Ability("Contre-coup", 0, [], contre_coup))
kaer_talk = ["Käer : Vous gaspillez votre énergie pour rien. Ne voyez-vous pas que vos efforts sont stériles ?",
             "Käer : C'est pathétique ! Il est évident que ce monde est perdu, et vous avec.",
             "Käer : Acceptez votre défaite. Ou voulez-vous paraître encore plus pitoyables ?\nKäer : Devenez mes acolytes, et accueillez votre pauvre réalité !"]
kaer_talk_idx = 0
kaer_talk_abil = Ability("Absorber-vie", 0, ["random_enemy"], None, text = kaer_talk[0])

# abilité de Käer
def absorber_vie(author, args):
    global Fred_spectre, kaer_talk_idx, kaer_talk_abil

    t_enemy = args[0]
    author.heal(30)
    Fred_spectre.set_effect("étourdi", True)
    print(author.nom, "démotive", Fred_spectre.nom, "!")
    t_enemy.set_effect("étourdi", True)
    print(author.nom, "démotive", t_enemy.nom, "!")

    kaer_talk_idx += 1
    if kaer_talk_idx == len(kaer_talk):
        kaer_talk_idx = 0
    kaer_talk_abil.text = kaer_talk[kaer_talk_idx]

kaer_talk_abil.fonc = absorber_vie
Kaer.add_ability(kaer_talk_abil)

Akordd = Char("Akordd Keyl", 150, 15, 50, ["ability Séduire", "defend", "ability Séduire", "defend", "ability Séduire", "ability Harmoniser"])
Akordd.add_ability(Ability("Séduire", 0, [], seduire))

Markatt = Char("Markatt Keyl", 300, 50, 20, ["defend", "ability Enchaîner random_enemy distinct_random_enemy", "defend", "ability Enchaîner random_enemy distinct_random_enemy", "defend", "ability Fire-symphony"])
Markatt.add_ability(Ability("Enchaîner", 0, ["random_enemy", "distinct_random_enemy"], enchainer))
Markatt.add_ability(Ability("Fire-symphony", 0, [], fire_symphony))

# abilité d'Akordd Keyl
def harmoniser(author, args):
    global Markatt

    # args == []
    Markatt.buff("force", 0.4)
    author.buff("défense", 0.4)

Akordd.add_ability(Ability("Harmoniser", 0, [], harmoniser))

Hypsiloxis = Char("Hypsiloxis", 350, 50, 30, ["skip"]*5 + ["ability Engendrer"])

# abilité d'Hypsiloxis
H_timing = 0
def engendrer(author, args):
    global ENNEMIS, H_timing

    # args == []
    if H_timing % 3 == 0:
        new_m = copy.deepcopy(Hyps_Mouth)
        print("Une autre Bouche apparaît.")
    else:
        new_m = copy.deepcopy(Hyps_Eye)
        print("Un autre Oeil apparaît.")
    new_m.reset()
    ENNEMIS.insert(-1, new_m)
    new_m.defend()
    H_timing += 1
    author.set_effect("not_my_turn", True)

Hypsiloxis.add_ability(Ability("Engendrer", 0, [], engendrer))

Loprex = Char("Sir Loprex", 300, 25, 25, ["defend", "defend", "defend", "ability Châtiment"])
Loprex.add_ability(Ability("Châtiment", 0, [], chatiment, "", "Loprex : Tu m'APPARTIENS !"))

# abilité de Fred
def detruire_le_joug(author, args):
    global Loprex

    # args == []
    author.buff("force", author.get_effect("électrocution"))
    author.attack(Loprex)

Loprex_Guard = Char("Garde de Loprex", 150, 20, 25, ["ability Choc-électrique lowestElectrocution_enemy"]*3 + ["defend"])
Loprex_Guard.add_ability(Ability("Choc-électrique", 0, ["lowestElectrocution_enemy"], choc_electrique))
Loprex_Guard2 = copy.deepcopy(Loprex_Guard)


TEAM_FRED.append(Fred)

def setENNEMIS(*E):
    global ENNEMIS
    ENNEMIS = list(E)

def loadTeam():
    global TEAM_FRED
    TEAM_FRED = []
    n = getone("team_fred")
    for c in n:
        if c == '1':
            TEAM_FRED.append(Fred)
        elif c == '2':
            TEAM_FRED.append(Coupbeau)
        elif c == '3':
            TEAM_FRED.append(Zadriel)
        elif c == '4':
            TEAM_FRED.append(Fred_spectre)

def saveTeam():
    n = ""
    for c in TEAM_FRED:
        if c == Fred:
            n += "1"
        elif c == Coupbeau:
            n += "2"
        elif c == Zadriel:
            n += "3"
        elif c == Fred_spectre:
            n += "4"
    saveone("team_fred", n)

########### COMBAT ###########
def ask_arg(author, arg: str):
    global TEAM_FRED, ENNEMIS, MANA, MAX_MANA

    if arg == "target_enemy":
        while True:
            print("Qui est l'objectif ?")
            print_liste([m.nom for m in ENNEMIS])
            print("(Écris 'x' ou 'retour' pour revenir en arrière.)")
            target = input("Numéro de la sélection : ")
            print()
            if target in [str(i+1) for i in range(len(ENNEMIS))]:
                target = int(target) - 1
                enn = ENNEMIS[target]
                if enn.PV == 0:
                    print("Cet ennemi est déjà hors de combat !\n")
                else:
                    return enn

            elif target.lower() in ("x", "retour"):
                return False
                            
            else:
                print("Sélection invalide.\n")

    elif arg == "target_ally":
        while True:
            print("Qui est l'objectif ?")
            print_liste([m.nom for m in TEAM_FRED])
            print("(Écris 'x' ou 'retour' pour revenir en arrière.)")
            target = input("Numéro de la sélection : ")
            print()
            if target in [str(i+1) for i in range(len(TEAM_FRED))]:
                target = int(target) - 1
                ally = TEAM_FRED[target]
                if ally.PV == 0:
                    print("Cet allié est déjà hors de combat !\n")
                else:
                    return ally

            elif target.lower() in ("x", "retour"):
                return False
                            
            else:
                print("Sélection invalide.\n")
    
    elif arg == "other_target_ally":
        while True:
            print("Qui est l'objectif ?")
            print_liste([m.nom for m in TEAM_FRED])
            print("(Écris 'x' ou 'retour' pour revenir en arrière.)")
            target = input("Numéro de la sélection : ")
            print()
            if target in [str(i+1) for i in range(len(TEAM_FRED))]:
                target = int(target) - 1
                ally = TEAM_FRED[target]
                if ally.PV == 0:
                    print("Cet allié est déjà hors de combat !\n")
                elif ally == author:
                    print("Cette abilité ne peut pas s'appliquer soi-même.\n")
                else:
                    return ally

            elif target.lower() in ("x", "retour"):
                return False
                            
            else:
                print("Sélection invalide.\n")
    
    return False

already = [] # personnages qui ont déjà été l'objectif pour ce tour et cet ennemi
def get_enn_arg(author, arg: str):
    global TEAM_FRED, ENNEMIS, MANA, MAX_MANA, already

    info = arg.split('_')

    if "ally" in info:
        choose_from = [m for m in ENNEMIS if m.PV > 0]
    elif "enemy" in info:
        choose_from = [m for m in TEAM_FRED if m.PV > 0]
    else:
        choose_from = [m for m in ENNEMIS + TEAM_FRED if m.PV > 0]

    if "distinct" in info:
        choose_from = [m for m in choose_from if m not in already]

    if len(choose_from) == 0:
        return None
    
    # renvoie l'indice d'elem dans l, s'il apparaît plusieurs fois, en choisit un aléatoirement
    def random_index(l, elem):
        idx_list = [i for i in range(len(l)) if l[i] == elem]
        for k in range(len(idx_list)):
            # échange deux éléments aléatoires
            i = randint(0, len(idx_list)-1)
            j = randint(0, len(idx_list)-1)
            v = idx_list[i]
            idx_list[i] = idx_list[j]
            idx_list[j] = v
        return idx_list[0]

    if "random" in info:
        idx = randint(0, len(choose_from) - 1)
        already.append(choose_from[idx])
        return choose_from[idx]
    elif "highestPV" in info:
        PV_list = [m.PV for m in choose_from]
        idx = random_index(PV_list, max(PV_list))
        already.append(choose_from[idx])
        return choose_from[idx]
    elif "lowestPV" in info:
        PV_list = [m.PV for m in choose_from]
        idx = random_index(PV_list, min(PV_list))
        already.append(choose_from[idx])
        return choose_from[idx]
    elif "lowestShield" in info:
        shield_list = [m.shield for m in choose_from]
        idx = random_index(shield_list, min(shield_list))
        already.append(choose_from[idx])
        return choose_from[idx]
    elif "highestHypnose" in info:
        hypnose_list = [m.get_effect("hypnose") for m in choose_from]
        for u in range(len(hypnose_list)):
            if hypnose_list[u] == None:
                hypnose_list[u] = 0
        idx = random_index(hypnose_list, max(hypnose_list))
        already.append(choose_from[idx])
        return choose_from[idx]
    elif "lowestElectrocution" in info:
        electroc_list = [m.get_effect("électrocution") for m in choose_from]
        for u in range(len(electroc_list)):
            if electroc_list[u] == None:
                electroc_list[u] = 0
        idx = random_index(electroc_list, min(electroc_list))
        already.append(choose_from[idx])
        return choose_from[idx]
    else:
        for i in range(len(choose_from)):
            if "#" + str(i+1) in info:
                if i >= len(choose_from):
                    idx = randint(0, len(choose_from) - 1)
                    already.append(choose_from[idx])
                    return choose_from[idx]
                already.append(choose_from[i])
                return choose_from[i]

def init_ACTIONS():
    global ACTIONS
    for m in TEAM_FRED:
        ACTIONS[m] = None

def new_ACTIONS():
    global ACTIONS
    for m in TEAM_FRED:
        if m.PV > 0 or m.spectre:
            ACTIONS[m] = None

def has_acted(m):
    global ACTIONS
    if m.PV > 0 or m.spectre:
        return ACTIONS[m] != None
    return None

def all_acted():
    global ACTIONS
    for m in TEAM_FRED:
        if has_acted(m) == False:
            return False
    return True

def lancer_combat(final = False):
    global ENNEMIS, TEAM_FRED, MANA, MAX_MANA, ACTIONS, already, H_timing, Fred
    if final:
        stay("Combat ?\n")
    else:
        stay("Combat !\n")

    for member in ENNEMIS:
        member.reset()
    H_timing = 0

    init_ACTIONS()

    MANA = 0

    while (sum([m.PV for m in TEAM_FRED]) > 0 and sum([m.PV for m in ENNEMIS]) > 0) and (not Fred.effect_is("final_win", True) or not final):
        # ---- enemy's turn ----
        print("---------------< C'est le tour de l'adversaire. >---------------\n")

        for member in ENNEMIS:
            member.reset_shield()
            member.set_effect("contre-coup", False)
            member.set_effect("not_my_turn", False)
            member.set_effect("surcharge", False)

        for member in ENNEMIS: # les ennemis agissent
            if member.PV > 0 and not member.effect_is("not_my_turn", True):
                if not member.effect_is("étourdi", True):
                    action = member.get_seq()

                    if action == "defend":
                        member.defend()

                    else:
                        already = []
                        action = action.split(" ")
                        if len(action) > 0:
                            if action[0] == "attack":
                                member.attack(get_enn_arg(member, action[1]))

                            elif action[0] == "heal":
                                member.heal(int(action[1]))

                            elif action[0] == "ability":
                                abil = member.get_ability(action[1])
                                if abil != None:
                                    arguments = [get_enn_arg(member, action[k]) for k in range(2, len(action))]
                                    abil.execute(member, arguments)

                                else:
                                    print(member.nom, "passe son tour.")

                            else:
                                print(member.nom, "passe son tour.")

                        else:
                            print(member.nom, "passe son tour.")

                else :
                    print(member.nom, "est étourdi.")
                    member.set_effect("étourdi", False)

                print()
                member.next_seq()

        for member in ENNEMIS + TEAM_FRED:
            member.short_stats()

        input()

        # ---- Fred's team's turn ----
        print("---------------< C'est ton tour. >---------------")

        mana_up()
        new_ACTIONS()
        for member in TEAM_FRED:
            member.reset_shield()
            if member.effect_is("étourdi", True):
                ACTIONS[member] = "étourdi"
                member.set_effect("étourdi", False)
            if member.effect_is("surcharge", True):
                member.set_effect("surcharge", False)

        noms = [m.nom for m in TEAM_FRED]
        while not all_acted(): # les personnages agissent

            selection_m = True
            while selection_m: # sélection du personnage
                print(f"\nMANA : {MANA} / {MAX_MANA}\n")
                print("Qui doit agir ?")
                print_liste(noms)
                moving_ally = input("Numéro de la sélection : ")
                print()

                if moving_ally in [str(i+1) for i in range(len(noms))]:
                    moving_ally = int(moving_ally) - 1
                    member = TEAM_FRED[moving_ally]

                    if member.PV > 0 or member.spectre:

                        if member.effect_is("étourdi", True):
                            print(member.nom, "est étourdi.")
                        else:

                            if has_acted(member):
                                print(member.nom, "a déjà agi ce tour.")
                            else:

                                selection_m = False

                                action = 0
                                while action not in [str(i+1) for i in range(5)] + ["get_out"]:
                                    print("Que fais", member.nom, "?")
                                    print_liste(["Défendre", "Attaquer", "Effectuer une abilité", "Utiliser un objet", "Ne rien faire", "Voir statistiques"])
                                    print("(Écris 'x' ou 'retour' pour revenir en arrière.)")
                                    action = input("Numéro de la sélection : ")
                                    print()
                                    
                                    if action == "1": # defend
                                        member.defend()
                                        ACTIONS[member] = "defend"
                                        if final:
                                            exe_action(9292)

                                    elif action == "2": # attack
                                        target = 0
                                        selection = True
                                        while selection:
                                            print("Qui est l'objectif ?")
                                            print_liste([m.nom for m in ENNEMIS])
                                            print("(Écris 'x' ou 'retour' pour revenir en arrière.)")
                                            target = input("Numéro de la sélection : ")
                                            print()
                                            if target in [str(i+1) for i in range(len(ENNEMIS))]:
                                                target = int(target) - 1
                                                enn = ENNEMIS[target]
                                                if enn.PV == 0:
                                                    print("Cet ennemi est déjà hors de combat !\n")
                                                    target = 0
                                                else:
                                                    member.attack(enn)
                                                    selection = False
                                                    ACTIONS[member] = "attack"
                                                    if final:
                                                        exe_action(9292)
                                                
                                            elif target.lower() in ("x", "retour"):
                                                action = 0
                                                selection = False
                                                
                                            else:
                                                print("Sélection invalide.\n")

                                    elif action == "3": # perform ability
                                        selection = True
                                        while selection:
                                            print("Les abilités de", member.nom, ":")
                                            print_liste([a.get_desc_text() for a in member.abilities])
                                            print("(Écris 'x' ou 'retour' pour revenir en arrière.)")
                                            selected = input("Numéro de la sélection : ")
                                            print()
                                            if selected in [str(i+1) for i in range(len(member.abilities))]:
                                                selected = int(selected) - 1
                                                abil = member.abilities[selected]

                                                if abil.nom == "Acte du Kapitaine" and has_acted(Coupbeau) != False:
                                                    print("Kap. Coupbeau a déjà agi ou ne peut pas agir ce tour.\n")
                                                elif abil.nom == "Acte du Kapitaine" and has_acted(Zadriel) != False:
                                                    print("Kap. Zadriel a déjà agi ou ne peut pas agir ce tour.\n")
                                                else:

                                                    if abil.cout <= MANA:
                                                        arguments = []
                                                        for a in abil.args:
                                                            answer = ask_arg(member, a)
                                                            if answer == False:
                                                                action = 0
                                                                break
                                                            else:
                                                                arguments.append(answer)
                                                        
                                                        if action != 0:
                                                            MANA -= abil.cout
                                                            abil.execute(member, arguments)
                                                            ACTIONS[member] = "ability"

                                                        selection = False
                                                    
                                                    else:
                                                        print("Tu n'as pas assez de mana.\n")

                                            elif selected.lower() in ("x", "retour"):
                                                action = 0
                                                selection = False
                                                
                                            else:
                                                print("Sélection invalide.\n")

                                    elif action == "4": # use object
                                        if INVENTORY.get_len() == 0:
                                            print("Tu n'as pas d'objets !\n")
                                            action = 0
                                        else:
                                            selected = 0
                                            selection = True
                                            while selection: # sélection de l'objet
                                                print("Choisis un objet :")
                                                print_liste([obj.nom + f" ({obj.desc})" for obj in INVENTORY.get_contenu()])
                                                print("(Écris 'x' ou 'retour' pour revenir en arrière.)")
                                                selected = input("Numéro de la sélection : ")
                                                print()
                                                if selected in [str(i+1) for i in range(INVENTORY.get_len())]:
                                                    selected = int(selected) - 1
                                                    obj = INVENTORY.get_contenu()[selected]
                                                    effet = obj.effet.split(" ")

                                                    if effet[0] == "heal":
                                                        member.heal(int(effet[1]))

                                                    elif effet[0] == "mana":
                                                        mana_up(int(effet[1]))
                                                        print("Tu gagnes", effet[1], "points de mana.")

                                                    elif effet[0] == "special":
                                                        if effet[1] == "none":
                                                            obj.special()
                                                        elif effet[1] == "all_allies":
                                                            obj.special(TEAM_FRED)
                                                        elif effet[1] == "all_enemies":
                                                            obj.special(ENNEMIS)
                                                        

                                                    INVENTORY.enlever(obj)
                                                    ACTIONS[member] = "object"

                                                    selection = False

                                                elif selected.lower() in ("x", "retour"):
                                                    action = 0
                                                    selection = False
                                                    
                                                else:
                                                    print("Sélection invalide.\n")

                                    elif action == "5": # skip
                                        print(member.nom, "passe son tour.")
                                        ACTIONS[member] = "skip"

                                    elif action == "6": # show stats
                                        member.print_stats()
                                        action = 0

                                    elif action in ("x", "retour"): # revenir à la sélection du personnage
                                        selection_m = True
                                        action = "get_out"

                                    else:
                                        print("Sélection invalide.\n")

                    else:
                        print(member.nom, "est hors combat.")

                else:
                    print("Sélection invalide.\n")

        print()

        for member in ENNEMIS + TEAM_FRED:
            member.short_stats()

    if sum([m.PV for m in TEAM_FRED]) == 0 and (not final or not Fred.effect_is("final_win", True)):
        print("Tu as perdu.\n")
        won = False
    else:
        print("Tu as gagné !\n")
        won = True

    for member in TEAM_FRED:
        member.reset()

    return won

def loadInventory():
    INVENTORY.espace = getone("espace_sac")
    nb_items_sac = getone("nb_items_sac")
    for i in range(nb_items_sac):
        obj = trouverObjet(getone("sac_item_" + str(i+1)))
        if obj != None:
            INVENTORY.ajouter(obj, False)

def saveInventory():
    saveone("espace_sac", INVENTORY.espace)
    saveone("nb_items_sac", INVENTORY.get_len())
    for i, e in enumerate(INVENTORY.contenu):
        saveone("sac_item_" + str(i+1), e.ID)

########### MOBILITÉ ###########
LIEU = tour_fort
PIECE = chambre_Fred

def myloc():
    if PIECE == NoPiece:
        print("Tu es dans :", LIEU.nom)
    else:
        print("Tu es dans :", PIECE.nom + ";", LIEU.nom)
    print()

def update():
    print()
    if PIECE == NoPiece:
        LIEU.printme()
    else:
        PIECE.printme()

def sortir():
    global PIECE
    if PIECE == NoPiece:
        print("Tu n'es pas dans une pièce.\n")
    elif PIECE.ouvert:
        PIECE = NoPiece
        LIEU.printme()
    else:
        print("Tu ne peux pas sortir de cette pièce.\n")

def entrer(p):
    global PIECE
    if p.ouvert:
        PIECE = p
        p.printme()
    else:
        print("Cette pièce est fermée.\n")

def aller(L):
    global LIEU, PIECE
    LIEU = L
    PIECE = NoPiece
    L.printme()

def loadPlace():
    global LIEU, PIECE, liste_lieux
    noms_lieux = [l.nom for l in liste_lieux]
    LIEU = liste_lieux[noms_lieux.index(getone("LIEU"))]
    nom_piece = getone("PIECE").lower()
    if nom_piece == "aucune":
        PIECE = NoPiece
    else:
        PIECE = LIEU.get_by_name(nom_piece)

def savePlace():
    saveone("LIEU", LIEU.nom)
    saveone("PIECE", PIECE.nom)

########### MAIN / HISTOIRE ###########
run = True
dance_count = 0
papa_questions = ""
papa_murailles_reponses = ["Loprex : Euh... Rien d'intéressant mon fils. Maintenant, laisse-moi tranquille.",
                           "Loprex : Ne demande pas cela, Fred.",
                           "Loprex : Fred, derrière les murailles, il y a vide, chaos, un feu millénaire sans visage qui déchire les âmes, une atrocité sans taille !",
                           "Loprex (très fâché) : Ça suffit ! Ne me le demande plus !",
                           "Loprex : Qu'est-ce que je t'ai dis ? Vas t'en !"] # \n\nC'est injuste ! Qu'est-ce qu'il peut bien cacher ?\nQui d'autre peut bien le savoir...?\nDevrais-tu le découvrir par toi-même ?
papa_murailles_count = 0
portal_ouvert = False
hors_fort_walk = 0
temple_bonjour = False
temple_question = False
malaxar_question_count = 0
fred_can_leave = False
progress_lecons_combat = 0
port_question = False
labo_inspected = False
fair_escape_attempts = 0
games_played = 0
roue_done = False
cible_done = False
cartes_done = False
car_done = False
kebabs = 0
ended_game = False

def saveVars():
    saveone("dance_count", dance_count)
    saveone("papa_questions", papa_questions)
    saveone("papa_murailles_count", papa_murailles_count)
    saveone("portal_ouvert", portal_ouvert)
    saveone("hors_fort_walk", hors_fort_walk)
    saveone("temple_bonjour", temple_bonjour)
    saveone("temple_question", temple_question)
    saveone("malaxar_question_count", malaxar_question_count)
    saveone("fred_can_leave", fred_can_leave)
    saveone("port_question", port_question)
    saveone("labo_inspected", labo_inspected)
    saveone("fair_escape_attempts", fair_escape_attempts)
    saveone("games_played", games_played)
    saveone("roue_done", roue_done)
    saveone("cible_done", cible_done)
    saveone("cartes_done", cartes_done)
    saveone("car_done", car_done)
    saveone("kebabs", kebabs)
    saveone("progress_lecons_combat", progress_lecons_combat)
    saveone("ended_game", ended_game)

def loadVars():
    global papa_murailles_count, portal_ouvert, hors_fort_walk, temple_bonjour, temple_question, malaxar_question_count
    global fred_can_leave, labo_inspected, port_question, dance_count, papa_questions, fair_escape_attempts, games_played
    global car_done, cible_done, roue_done, cartes_done, kebabs, progress_lecons_combat, run, ended_game
    dance_count = getone("dance_count")
    papa_questions = getone("papa_questions")
    papa_murailles_count = getone("papa_murailles_count")
    portal_ouvert = getone("portal_ouvert")
    hors_fort_walk = getone("hors_fort_walk")
    temple_bonjour = getone("temple_bonjour")
    temple_question = getone("temple_question")
    malaxar_question_count = getone("malaxar_question_count")
    fred_can_leave = getone("fred_can_leave")
    labo_inspected = getone("labo_inspected")
    port_question = getone("port_question")
    games_played = getone("games_played")
    fair_escape_attempts = getone("fair_escape_attempts")
    roue_done = getone("roue_done")
    cible_done = getone("cible_done")
    cartes_done = getone("cartes_done")
    car_done = getone("car_done")
    kebabs = getone("kebabs")
    progress_lecons_combat = getone("progress_lecons_combat")
    ended_game = getone("ended_game")
    run = not ended_game


def actions_1111():
    temple.add_action("Il y a-t-il une prophétie ?", {"print": "Goday : Une prophétie ? Non, aucune...", "return": "malaxar_question"})
    salle_reunion.add_action("Demander à propos de Malaxar", {"print": "Villageois 1 : C'est le monde !\nVillageois 2 : Très ancien et très vaste.\nVillageois 3 : Mais Malaxar est devenu dangereux...\nVillageois 1 : Il paraîtrait que, il y a longtemps, le Grand Noyau a été corrompu par des gaz cosmiques obscurs...\nVillageois 2 : Et depuis, les êtres qui habitent Malaxar sont, eux aussi, corrompus.\nVillageois 3 : Certains le sont particulièrement...\nVillageois 1 : Ce sont les Ombres. La légende raconte que, lorsque Malaxar a été maudit, les cinq clés de sa corruption\nont été déposées dans les âmes de cinq habitants de Malaxar.\nVillageois 2 : En théorie, quiconque qui veuille guérir Malaxar devrait récupérer ces cinq clés...\nVillageois 1 : Mais qui sont-ils ? Et où sont-ils ? Personne ne sait...", "return": "malaxar_question"})
    chez_domila.add_action("Demander à propos de Malaxar", {"print": "Domila : Malaxar a une sorte de coeur, un endroit ou toute l'énergie vitale du monde converge : c'est le Grand Noyau.\nDomila : Tout le vivant de Malaxar est connecté à ce Grand Noyau. Mais il est malade...", "return": "malaxar_question"})
    hotel.add_action("Demander à propos de Malaxar", {"print": "Ajan : Malaxar ! Les voyageurs m'ont dit que c'est grand et varié.\nAjan : J'ai entendu parler de quatre grandes régions : Les Mers, Les Plaines, Le Désert et les montagnes des Profondeurs.\nAjan : Et toi, d'où viens-tu ?\nAjan : Tu ne veux pas me le dire ?", "return": "malaxar_question"})

def actions_2222():
    Fred.add_ability(Ability("Cultiver", 3, ["target_ally"], cultiver, "Un allié gagne 20% de force et 20% de plus pour chaque mana restant. Défend à 75%."))
    # Fred.add_ability(Ability("Vitalité fondamentale", 0, [], vita_fonda, "Toute l'équipe récupère 10 PV pour chaque point de mana restant. Consomme tout ton mana."))

def action_7272():
    ElectroJake.seq = ["ability abil-trainer"]

def actions_3333():
    fight_club.rm_action("Apprendre à combattre")
    fight_club.add_action("S'entraîner au combat", {"return": "train_combat"})
    ElectroJake.add_ability(Ability("Auto-fix", 0, [], auto_fix))
    ElectroJake.add_ability(Ability("Plasma-shot", 0, ["#1_enemy"], plasma_shot))
    ElectroJake.seq = ["defend", "attack #1_enemy", "defend", "attack #1_enemy", "ability Auto-fix", "ability Plasma-shot #1_enemy"]

def action_8383():
    if Fred.get_ability("Détruire le joug") == None:
        Fred.add_ability(Ability("Détruire le joug", 4, [], detruire_le_joug, "Gagne 100% de force pour chaque point d'électrocution. Attaque Loprex."))

def action_9292():
    if Fred.get_ability("Être") != None:
        Fred.rm_ability("Être")

HISTORIEL = { # id: action (lambda function)
    9247: lambda: bureau_Loprex.add_action("Demander à ton père ce qu'il y a derrière les murailles", {"print": papa_murailles_reponses[0], "return": "add_papa_murailles"}),
    2545: lambda: bureau_Loprex.mod_action("Demander à ton père ce qu'il y a derrière les murailles", {"print": papa_murailles_reponses[0], "return": "add_papa_murailles"}),
    2546: lambda: bureau_Loprex.mod_action("Demander à ton père ce qu'il y a derrière les murailles", {"print": papa_murailles_reponses[1], "return": "add_papa_murailles"}),
    2547: lambda: bureau_Loprex.mod_action("Demander à ton père ce qu'il y a derrière les murailles", {"print": papa_murailles_reponses[2], "return": "add_papa_murailles"}),
    2548: lambda: bureau_Loprex.mod_action("Demander à ton père ce qu'il y a derrière les murailles", {"print": papa_murailles_reponses[3], "return": "add_papa_murailles"}),
    2549: lambda: bureau_Loprex.mod_action("Demander à ton père ce qu'il y a derrière les murailles", {"print": papa_murailles_reponses[4], "return": "add_papa_murailles"}),
    6784: lambda: tour_de_garde.add_action("Prendre silencieusement les clés", {"return": "ouvrir_portal", "print": "Tu prends les clés du Grand portail."}),
    3452: lambda: tour_de_garde.ouvrir(),
    8833: add_murailles_doute,
    3211: lambda: portal.ouvrir(),
    7810: lambda: tour_de_garde.rm_action("Prendre silencieusement les clés"),
    9187: lambda: hors_fort.mod_action("Avancer", {"print": "Tu marches et rencontres enfin deux voyageurs.\nVoyageur 1 : Lumière, nouvel être ! Es-tu perdu ? Nous allons au village le plus proche. Veux-tu nous accompagner ?", "return": "meet_traveler"}),
    1654: lambda: hors_fort.rm_action("Avancer"),
    2317: lambda: hors_fort.add_action("Suivre les voyageurs", {"return": "to_ajxu"}),
    1997: lambda: temple.add_action("Qu'est-ce que Malaxar ?", {"print": "Goday : Malaxar est notre Dieu. Nous croyons que tout est Malaxar, Malaxar est tout. Une pomme est Malaxar, ce village est Malaxar, tu es Malaxar.", "return": "temple_question"}),
    2644: lambda: temple.add_action("Que veut dire 'que Malaxar t'illumine' ?", {"print": "Goday : Quand tu souhaites à quelqu'un que Malaxar l'illumine, tu lui souhaites en fait que Malaxar lui révèle ses plis, infinis et mystérieux.\nGoday : Cette révélation se traduit par une prise de conscience qui permet à cette personne de prendre le chemin qu'elle veut réellement et librement.", "return": "temple_question"}),
    1111: actions_1111,
    6509: lambda: fight_club.mod_action("Dire bonjour", {"print": "Electro Jake : Bonjour Fred ! Prêt pour un défi ?"}),
    7725: lambda: fight_club.add_action("Apprendre à combattre", {"return": "learn_combat"}),
    1002: lambda: chez_domila.add_action("Parler de ton projet", {"print": "Domila : Quoi ? Tu veux sauver Malaxar ?\nDomila : Ton intention est bonne, mais Malaxar est dangereux et très vaste.\nDomila : T'accompagner ? Oh non, non. Je ne peux pas. Je suis désolé, Fred !\nDomila : Mais vu que tu tiens à ta décision, je te soutiendrai !\nDomila : Que Malaxar t'illumine.\nDomila : Avant de partir, je te recommande de t'entraîner un peu au club de combat, si tu n'as pas d'expérience.", "return": "told_to_leave"}),
    4736: lambda: chez_domila.rm_action("Parler de ton projet"),
    5337: lambda: chez_domila.add_action("Partir du village", {"return": "PARTIR"}),
    2222: actions_2222,
    3563: lambda: ElectroJake.add_ability(Ability("abil-trainer", 0, [], abil_trainer)),
    7272: action_7272,
    3333: actions_3333,
    8659: lambda: chez_domila.rm_action("Partir du village"),
    2264: lambda: marche.rm_action("Acheter de l'huile"),
    5108: lambda: marche.add_action("Demander un transport", {"print": "Marin : Personne ne voudras te porter aussi loin ! Les Mers sont dangereuses...", "return": "transport_mer_ask"}),
    1670: lambda: marche.rm_action("Demander un transport"),
    9020: lambda: marche.add_action("Acheter une barque", {"print": "Tu parviens à acheter une barque et des rames à un pêcheur. Elle flotte déjà sur l'eau.", "return": "get_barque"}),
    6301: lambda: marche.rm_action("Acheter une barque"),
    2468: lambda: quai.add_action("Monter sur la barque et partir", {"return": "partir_mer"}),
    6026: lambda: bateauZadriel.rm_action("Parler à Zadriel"),
    7309: lambda: bateauCoupbeau.rm_action("Parler à Coupbeau"),
    4395: lambda: bateauZadriel.add_action("Revenir au continent", {"return": "back_to_continent"}),
    2394: lambda: bateauZadriel.rm_action("Revenir au continent"),
    8176: lambda: qqpart.rm_action("Combattre les yeux"),
    9360: lambda: qqpart.ouvrir(),
    2832: lambda: proche_labo.rm_action("Approcher le laboratoire"),
    1293: lambda: laboratoire.ouvrir(),
    7997: lambda: proche_labo.add_action("Parler avec Kus", {"return": "talk_Kus"}),
    5145: lambda: proche_labo.rm_action("Parler avec Kus"),
    1507: lambda: souterrain.ouvrir(),
    6632: lambda: milieu_desert.mod_action("Explorer", {"print": "Il ne reste plus rien d'intéressant dans les alentours."}),
    6902: lambda: setENNEMIS(Kus),
    7101: lambda: setENNEMIS(ElectroJake),
    9938: lambda: setENNEMIS(Hyps_Eye, Hyps_Eye2, Hyps_Mouth),
    4329: lambda: souterrain.ouvrir(),
    1312: lambda: setENNEMIS(Kaer),
    9388: lambda: souterrain.rm_action("???"),
    4410: lambda: setENNEMIS(Akordd, Markatt),
    8731: lambda: Fred.add_ability(Ability("Conviction", 3, [], conviction, "Toute l'équipe défend.")),
    7175: lambda: setENNEMIS(Hyps_Eye, Hyps_Eye2, Hyps_Mouth, Hypsiloxis),
    3573: lambda: antre.rm_action("Explorer l'antre"),
    8112: lambda: vallee.add_action("Marcher vers les hauts sommets", {"return": "walk_in_valley"}),
    7124: lambda: setENNEMIS(Loprex_Guard, Loprex_Guard2, Loprex),
    8383: action_8383,
    3922: lambda: Fred.rm_ability("Détruire le joug"),
    1028: lambda: vallee.mod_action("Marcher vers les hauts sommets", {"return": "reach_sommet_profond"}),
    1992: lambda: setENNEMIS(Fred),
    1325: lambda: Fred.add_ability(Ability("Être", 0, [], etre, "Tu es.")),
    9292: action_9292,
    9231: lambda: sommet.rm_action("Monter jusqu'au sommet"),
    5347: lambda: sommet.add_action("Libérer Malaxar", {"return": "free_Malaxar"}),
    1358: lambda: sommet.rm_action("Libérer Malaxar"),
    0: lambda: None
}
saved_action_count = 0

def saveAction(action_id):
    global saved_action_count
    saved_action_count += 1
    saveone("action_" + str(saved_action_count), action_id)
    saveone("saved_action_count", saved_action_count)

def exe_action(action_id, also_save = True):
    assert(action_id in HISTORIEL.keys())
    if also_save:
        saveAction(action_id)
    return HISTORIEL[action_id]()

def loadActions():
    global saved_action_count
    saved_action_count = getone("saved_action_count")
    for i in range(1, saved_action_count+1):
        action_id = getone("action_" + str(i))
        exe_action(action_id, False)

def action_response(res):
    global Ajxu, ajxu_pieces, tour_fort, tf_pieces, plaines_pales, hors_fort, village_fort, vf_pieces
    global PIECE, LIEU, papa_questions, papa_murailles_count, papa_murailles_reponses, portal_ouvert
    global hors_fort_walk, temple_bonjour, temple_question, fred_can_leave, Pain, ElectroJus, Huile
    global malaxar_question_count, INVENTORY, TEAM_FRED, ENNEMIS, MANA, MAX_MANA, run, dance_count
    global Fred, ElectroJake, port_pieces, Port, marche, quai, mers_pieces, Mers, Zadriel, Coupbeau
    global bateauCoupbeau, bateauZadriel, qqpart, plaines_pieces, Plaines, laboratoire, proche_labo
    global labo_inspected, Hyps_Eye, Hyps_Eye2, Hyps_Mouth, Kus, port_question, souterrain, Desert
    global milieu_desert, desert_pieces, Longue_vue, games_played, fair_escape_attempts, Foire
    global village_foire, cartes_done, kebabs, car_done, roue_done, cible_done, village_foire_pieces
    global foire_pieces, kebab, cible, portail_foire, portail_village, maison1, maison2, table_carte
    global roue, carrousel, taverne, magasin, boulangerie, Touche_clavecorgue, Chapeau_reddition
    global progress_lecons_combat, profondeurs, prof_pieces, antre, vallee, sommet, ended_game

    if res in ("papa1", "papa2"):
        papa_questions += res[-1]
        if "1" in papa_questions and "2" in papa_questions:
            if "N" not in papa_questions:
                exe_action(9247)
                papa_questions += "N"
    
    elif res == "add_papa_murailles":
        if papa_murailles_count < 4:
            papa_murailles_count += 1
            exe_action(2545 + papa_murailles_count)
        elif papa_murailles_count != 99:
            exe_action(8833)
            papa_murailles_count = 99
            exe_action(6784)
            exe_action(3452)

    elif res == "ouvrir_portal" and not portal_ouvert:
        portal_ouvert = True
        exe_action(3211)
        exe_action(7810)

    elif res == "leave_fort":
        aller(plaines_pales)
        PIECE = hors_fort

    elif res == "add_walk":
        if hors_fort_walk < 4:
            hors_fort_walk += 1
        else:
            exe_action(9187)

    elif res == "meet_traveler":
        exe_action(1654)
        exe_action(2317)

    elif res == "to_ajxu":
        print()
        stay("Vous arrivez à un village nommé 'Ajxu'.")
        stay("Vous êtes accueillis avec hospitalité. Tout le monde est aimable et respectueux avec toi.")
        stay("Bien que les voyageurs s'en aillent au bout d'une semaine, tu décides de rester.")
        stay("Tu te fais des amis, et même une famille autour de toi.")
        stay("C'est si... différent.")
        aller(Ajxu)
        return False

    elif res == "temple_bonjour":
        if not temple_bonjour:
            temple_bonjour = True
            exe_action(1997)
            exe_action(2644)

    elif res == "temple_question":
        if not temple_question:
            temple_question = True
            exe_action(1111)
            
    elif res == "combat_club_bonjour":
        exe_action(6509)
        exe_action(7725)

    elif res == "malaxar_question":
        if malaxar_question_count < 4:
            malaxar_question_count += 1
        elif not fred_can_leave:
            fred_can_leave = True
            exe_action(1002)
    
    elif res == "told_to_leave":
        exe_action(4736)
        exe_action(5337)

    elif res == "learn_combat":
        if progress_lecons_combat == 0:
            stay("Electro Jake et toi entrez dans une salle avec des tapis et des armes blanches en bois.")
            stay("Electro Jake : Le but d'un combat est simple : réduire les PV (Points de Vie) d'un adversaire à 0.")
            stay("Electro Jake : Pour cela, il faut attaquer l'adversaire. Tiens, prend cette épée. Je vais t'enseigner comment t'en servir.")
            stay("Electro Jake : Ton adversaire pourra aussi t'attaquer. Pour réduire les dommages reçus, tu peux te défendre.")
            stay("Electro Jake te montre les mouvements basiques d'attaque et de défense.")
            stay("Electro Jake : Il est bon de savoir que beaucoup d'adversaires suivent des séquences précises de mouvements.\nSi tu les repères, tu pourras connaître leurs mouvements à l'avance !")
            stay("Electro Jake : Essaye ce que je viens de te montrer. Haa !")
            exe_action(7101)
            won = lancer_combat()
            if not won:
                stay("Electro Jake : Tu as perdu. Mais ce n'est pas grave. Tu le feras mieux la prochaine fois !")
                stay("Electro Jake : Je ne t'ai pas encore tout appris ! Mais avant de continuer, tu dois pouvoir me vaincre !")
            else:
                stay("Electro Jake : Bien joué ! Tu m'as vaincu !")
                stay("Electro Jake : Je ne t'ai pas encore tout appris ! Reviens quand tu voudras continuer.")
                progress_lecons_combat += 1
        
        elif progress_lecons_combat == 1:
            stay("Electro Jake : Maintenant, je dois encore t'expliquer quelques notions.")
            stay("Electro Jake : Les abilités sont des actions spéciales qui te permettent de réaliser d'autres actions que celles que je t'ai montrées,\net même d'en réaliser plusieurs en un seul tour !")
            stay("Electro Jake : Pour effectuer une abilité, il te faut avoir suffisamment de mana.\nElectro Jake : La quantité nécessaire dépend de l'abilité.")
            stay("Electro Jake : Tu gagnes un point de mana au début de chaque tour.")
            stay("Electro Jake : Par ailleurs, ta force et ta défense peuvent varier pendant un combat.")
            stay("Electro Jake : Par exemple, une abilité peut te permettre de gagner de la force ou de la défense.")
            stay("Electro Jake : Les variations de force s'appliquent uniquement lors de ta prochaine attaque, et idem pour la défense.\nElectro Jake : Ensuite elles disparaissent.")
            stay("Electro Jake : Tu peux alors les accumuler pendant plusieurs tours !")
            stay("Electro Jake te montre une abilité.")
            exe_action(2222)
            stay("Electro Jake : Mettons tout cela en pratique. Haa !")
            exe_action(3563)
            exe_action(7272)
            won = lancer_combat()
            if not won:
                stay("Electro Jake : Tu as perdu. Mais ce n'est pas grave. Tu le feras mieux la prochaine fois !")
            else:
                stay("Electro Jake : Bien joué ! Tu m'as vaincu !")
                stay("Electro Jake : Reviens vers moi quand tu voudras pour que nous continuions à combattre.")
                stay("Electro Jake : Et voici un cadeau !")
                INVENTORY.ajouter(ElectroJus)
                exe_action(3333)
                progress_lecons_combat += 1

    elif res == "train_combat":
        exe_action(7101)
        won = lancer_combat()
        if not won:
            stay("Electro Jake : Tu as perdu. Mais ce n'est pas grave. Tu le feras mieux la prochaine fois !")
        else:
            stay("Electro Jake : Bien joué ! Tu m'as vaincu !")
        stay("Electro Jake : Reviens vers moi quand tu voudras pour que nous continuions à combattre.")
        stay("Electro Jake : Et voici un cadeau pour tes efforts !")
        INVENTORY.ajouter(ElectroJus)

    elif res == "PARTIR":
        exe_action(8659)
        stay("Au levé du Soleil, face au Temple, le village se réunit une dernière fois, pour te dire au revoir.")
        stay("Ajan : Fred, je connais deux personnes aussi légendaires que ta mission qui pourraient te venir en grande aide.")
        stay("Ajan : Ce sont les pirates Coupbeau et Zadriel, que tu trouveras dans les Mers.")
        stay("Tu te dis que c'est une bonne idée de te faire accompagner.")
        stay("Tous te souhaitent un bon voyage et que la Lumière de Malaxar t'accompagne tout le long. Le village espère te revoir, en particulier Domila.")
        stay("Tu salues ta famille une dernière fois, et tu t'élances vers ton destin...")
        stay("...tracé de ta propre main, sans prophétie pour le dicter.")
        stay("\nAprès une longue marche, tu arrives à un port.")
        aller(Port)

    elif res == "achat_huile":
        exe_action(2264)

    elif res == "ask_Kaps":
        if not port_question:
            exe_action(5108)
            port_question = True

    elif res == "transport_mer_ask":
        exe_action(1670)
        exe_action(9020)

    elif res == "get_barque":
        exe_action(6301)
        exe_action(2468)
        
    elif res == "partir_mer":
        print()
        stay("Tu commences à ramer sur ta barque modeste et t'éloignes du quai, sans savoir où cela te mènera.")
        stay("Au fur et à mesure que tu avances, les vagues deviennent plus hautes et puissantes. Tu perds de plus en plus ta stabilité.")
        stay("Tu continues à ramer comme tu peux jusqu'à ce que tu entres dans une féroce tempête.")
        stay("La surface de l'eau se fond dans les nuages noirs. Les énormes vagues secouent ta barque dans tous les sens,\nà laquelle tu t'accroches avec toutes tes forces. Tu ne distingues plus mer et ciel.")
        stay("Volent comme toi des tas de pierres, telle une sphère de débris qui tourne comme une toupie hors de contrôle.")
        stay("Ce chaos te mène finalement hors de la tempête. Là, tu rencontres un ciel clair et un tapis d'eau.")
        stay("Tu vois au loin deux grands navires. Tu te rapproches, et tu remarques alors qu'il sont en train de se tirer des boules de canon dessus.")
        stay("Tu montes sur l'un des navires, et malgré l'activité bouillonante de l'équipage, tu obtiens une réponse à ta question :")
        stay("Tu te trouves sur le bateau du Kapitaine Coupbeau, et l'autre est celui du Kapitaine Zadriel !")
        aller(Mers)
        entrer(bateauCoupbeau)
        return False

    elif res == "spoke_Zadriel":
        exe_action(6026)
        exe_action(7309)
        stay("Les deux bateaux se rapprochent, et Coupbeau monte à bord de celui de Zadriel.")
        stay("Suite à une brève discussion, les deux Kapitaines serrent leurs mains.\nLe sourire de Coupbeau est éclatant, tandis que Zadriel grogne de manière intimidante en signe de son accord.")
        stay("Toi qui vois enfin les deux héros des Mers réunis, tu interviens pour leur expliquer ta mission.\nEt tu leur demandes de t'accompagner.")
        stay("Les Kapitaines semblent un peu surpris, mais l'idée leur plaît.")
        stay("Ils acceptent de t'accompagner !")
        TEAM_FRED.append(Coupbeau)
        TEAM_FRED.append(Zadriel)
        exe_action(8731)
        exe_action(4395)

    elif res == "back_to_continent":
        exe_action(2394)
        stay("Il fait un très beau temps lorsque vous décidez de partir.\nLes rayons du Soleil font sur l'eau des étincelles comme celles d'un ciel étoilé.\nEt des poissons dansent sous les douces vagues qui bercent le bateau de Zadriel.")
        stay("C'est alors que tu vois au loin...")
        stay("La terrible tempête, vers laquelle vous vous dirigez.")
        stay("Tu préviens les Kapitaines du danger qui vous attend là-bas.")
        stay("Mais ils t'assurent que le navire tiendra sans problème.")
        stay("Tu paniques et tu te jètes par terre.")
        stay("Vous arrivez dans la tempête. Et à ta grande surprise, le bateau imposant traverse les vagues féroces proprement,\nsans se dévier même un peu de son droit chemin.")
        stay("En arrivant au port, vous amarrez le bateau au quai et démarrez la marche vers les Plaines.")
        aller(Plaines)
        PIECE = qqpart

    elif res == "fight_eyebunch":
        exe_action(9938)
        won = lancer_combat()
        if won:
            exe_action(8176)
            stay("Coupbeau : Hypsiloxis. Ne le connais-tu pas ?")
            stay("Coupbeau : C'est une créature mystérieuse, dont les yeux et les bouches s'étendent à peu près partout sur Malaxar.\nCoupbeau : Celui qui voit tout.")
            stay("Coupbeau : Une légende raconte qu'un jour, il dévorera Malaxar.")
            exe_action(9360)

    elif res == "meet_Kus":
        exe_action(2832)
        stay("Aussitôt il vous remarque, il saute et vous salue, en vous souriant sinistrement.")
        stay("Garçon : Bonjour, voyageurs ! Que faites-vous par ici ? Vous êtes-vous perdus ?")
        stay("Coupbeau : Bonjour ! Que savez-vous à propos de cette infrastructure ?")
        stay("Garçon : Oh, ceci... peut-être... éventuellement...")
        stay("Zadriel : De quoi s'agit-il ?")
        stay("Garçon : Hehehe...")
        stay("Garçon : Savez-vous à qui appartient ce laboratoire ?")
        stay("Zadriel : Absolument pas.")
        stay("Garçon : Hihihi...\nLe garçon se rapproche du laboratoire. Vous le suivez.")
        stay("Garçon : Bienvenue à mon palace !")
        stay("Coupbeau : Pouvons-nous entrer ?")
        stay("Garçon : Pourquoi pas...?")
        stay("Tu lui demandes son nom.")
        stay("Garçon : Comment je m'appelle ? Kus ! Je m'appelle Kus ! Hahahaha !")
        exe_action(1293)

    elif res == "labo_inspect" and not labo_inspected:
        labo_inspected = True
        exe_action(7997)

    elif res == "talk_Kus":
        stay("Kus : Étant donné que ce monde existe, ne devrait-il pas être parfait ? Et bien, où est-elle, cette perfection ?")
        stay("Kus : Il devint aveugle. Il essayait de trouver rien d'autre que l'exact opposé à la réalité.")
        stay("Kus : Danilov, malheureux...\nKus : Danilov Kölichstein était un grand scientifique.")
        stay("Coupbeau : Que lui est-il arrivé ?")
        stay("Kus : Il est disparu...")
        stay("Tu demandes à Kus s'il connaissait le scientifique.")
        stay("Kus : C'était mon frère... Hehe...")
        stay("Coupbeau : Oh, nous sommes désolés pour toi !")
        stay("Kus : Oh, de toute façon, il était un peu fou...")
        stay("Kus : Il était intelligent et très analytique, un pur scientifique. Parfois il était même trop analytique. Mais ce n'était pas du tout quelqu'un de froid.\nIl regardait toujours les détails, les bagatelles, et trouvait des erreurs dans tout. Il était même impertinent.\nIl s'inquiétait pour n'importe quoi, voyait tout comme inacceptable.")
        stay("Kus : Un jour, il décida de se débarasser des toutes ces imperfections : si Malaxar était parfait, ce serait incontestable,\net il n'aurait plus à se pleindre des détails, il accepterait le monde.")
        stay("Kus : Il ne souhaitait autre chose qu'être heureux, comme tout le monde.")
        stay("Kus : Malheureusement, sa conviction se transforma en obsession, puis en trauma paranoïaque.")
        stay("Tu demandes à Kus comment Danilov est mort.")
        stay("Kus reste silencieux, puis te répond sur un ton obscur :")
        stay("Kus : Je le tuai.")
        stay("Vous êtes surpris.\nKus met alors ses genoux à terre et se tourne vers le ciel :\nKus : C'est moi qui tuai Danilov Kölichstein !!!")
        stay("Kus : Il était fou... beaucoup trop ! Malaxar, Malaxar ! Ce monde m'importe si peu. Il ôta la raison de mon frère, le rendant esclave des forces cosmiques !")
        stay("Kus : En fait, je l'ai sauvé ! Il était déjà perdu... Hahahaha !")
        stay("Zadriel : Cela te paraît drôle ?")
        stay("Kus : Hihihihi ! Tout me faire rire ! HAhHAhahAHhAhAH !")
        stay("Kus : Tout est chaos. CHAOS ! Rien n'est mérité dans l'Existence ! Malaxar est un paradoxe !")
        stay("Kus : Hahahahaha ! Chaos ! Tout est privé de sens !")
        stay("Craintif, tu lui demandes qui il est réellement.")
        stay("Kus : Ahaha, quelle bonne question ! Mais au bout du compte, méritons-nous des noms ? Malaxar mérite-il le sien ?")
        stay("Kus : Je suis... Je suis...")
        stay("Kus : Danilov Kölichstein !!")
        stay("Kus entre en courant dans le laboratoire. Au bout de quelques instants, le toît s'en arrache et donne place à une énorme machine qui se lève, contrôlée à sa tête par Kus.")
        stay("Kus : Chaos, chaos, chaos ! Vous mourrez tous ! HIHIHIHAHA !")
        exe_action(6902)
        won = lancer_combat()
        if won:
            exe_action(5145)
            stay("Vous parvenez à neutraliser Kus, que vous posez par terre.")
            stay("Kus : Chaos, chaos ! Ce monde ne devrait pas exister...")
            stay("Tu lui répond que cela n'a aucune importance, que ce qui compte vraiment c'est d'avoir une vie et de lui donner un sens en en faisant quelque chose.")
            stay("Soudain, Kus s'évanouit, et une spectrale fumée noire sort de sa poitrine et fuit vers les profondeurs du ciel.")
            stay("C'était une Ombre !")
            stay("Tu as 1 clé de corruption de Malaxar.")
            INVENTORY.agrandir()
            INVENTORY.ajouter(Longue_vue)
            stay("Vous repartez alors à la recherche des autres Ombres...")
            aller(Desert)
            entrer(milieu_desert)

    elif res == "desert_door_found":
        exe_action(6632)
        stay("Vous ne voyez rien, mais décidez quand-même de vérifier s'il n'y a rien d'étrange dans les alentours.")
        stay("Fred trouve une porte carrée par terre.")
        stay("Vous vous efforcez de l'ouvrir, sans succès. Mais aussitôt vous abandonnez, la porte s'ouvre d'elle-même.")
        stay("Elle révèle alors un puis profond avec des escaliers qui vont jusqu'au fond.")
        exe_action(1507)

    elif res == "meet_Kaer":
        exe_action(4329)
        stay("Vous entendez la porte se fermer seule à la surface.\nLe souterrain est grand et très humide. De quoi se rejouir en plein milieu du désert.")
        stay("Mais c'est trop étrange... Il y a même quelques fuites !")
        stay("Vous avancez dans la sombre cavité souterraine.")
        stay("Et au fur et à mesure que vous avancez, vous entendez des pleurs, de plus en plus forts.\nIls semblent venir de partout, vous n'en trouvez pas l'origine.")
        stay("Quand ils sont assez forts pour faire trembler la terre, ils cessent soudainement.")
        stay("Ensuite, vous écoutez des pas qui s'approchent vers vous. Lents et imposants.")
        stay("Finalement, sur le fond obscur se découpe une silhouette.\nSon image s'éclaircit, et tu constates qu'il ressemble aux Kapitaines : chapeau triangulaire, blouse et sabre en main.")
        stay("Un léger sourire ironique se dessine sur son visage. Et quand il lève le regard vers vous...")
        stay("Tu découvres qu'au lieu d'une paire d'yeux, il porte une longue et moche cicatrice.")
        stay("Tu es paralysé. Quant aux Kapitaines, aussitôt ils ont vu le sujet mystérieux, ils se sont mis à trembler.")
        stay("Coupbeau et Zadriel : K-K-Kapitaine Käer ?!")
        # stay("Ils se connaissent déjà ? Qui est donc cet être qui effraie ainsi même les plus vaillants ?")
        stay("Käer : Aha ! Vous êtes tombés dans mon inévitable piège !")
        stay("Tu ne sais pas quoi faire. De fait, tu ne veux plus rien faire, mais seulement te jeter par terre et oublier l'Existence.\nTu te sens profondemment triste.")
        stay("Coupbeau : Tu étais mort ! Je l'ai vu de mes propres yeux.")
        stay("Käer (sarcastique) : Hmmm, sans doute !")
        stay("Käer : Je suis immortel, Coupbeau. Je meurs pour renaître. Et me voici, au milieu du désert abandonné.")
        stay("Un léger aura enveloppe les murs.\nLe Kapitaine Käer sourit maquiavéliquement pendant qu'il sent ton âme être lentement absorbée par le souterrain.")
        stay("Tu t'évanouis.")
        stay("Zadriel : Et bien, tu vas devoir encore renaître, bandit !")
        exe_action(1312)
        TEAM_FRED[0] = Fred_spectre
        won = lancer_combat()
        if won:
            TEAM_FRED[0] = Fred
            exe_action(9388)
            exe_action(4329)
            stay("Alors que les Kapitaines vainquent Käer, une fine et translucide image se forme au fond du souterrain.")
            stay("C'est celle d'un frigo — la tienne.")
            stay("Tu t'approches fantasmagoriquement du Kapitaine au visage cousu.")
            stay("Käer : Vous pouvez me vaincre. Mais l'obscurité est inévitable, c'est le vrai destin qui attend d'être accompli.")
            stay("D'une voix lointaine qui résonne à travers les murs, tu lui réponds que l'obscurité, c'est lui, et que tu ne\npermettra pas qu'il porte à nouveau ce chapeau.")
            stay("Alors Käer s'évanouit, son chapeau tombe, et une fumée mystique et obscure s'échappe de sa poitrine et traverse le plafond.")
            stay("C'était une Ombre !")
            stay("Tu as 2 clés de corruption de Malaxar.")
            INVENTORY.agrandir()
            INVENTORY.ajouter(Chapeau_reddition)
            stay("Ton image spectrale disparaît et tu te réveilles maladroitement dans ton vrai corps mécanique.")
            stay("Vous retournez alors à la surface du Désert et continuez votre voyage.")
            aller(village_foire)
            
    elif res == "roue_done" and not roue_done:
        games_played += 1
        roue_done = True

    elif res == "cartes_done" and not cartes_done:
        games_played += 1
        cartes_done = True

    elif res == "carrousel_done" and not car_done:
        games_played += 1
        car_done = True
    
    elif res == "cible_done" and not cible_done:
        games_played += 1
        cible_done = True

    elif res == "eat_kebab":
        kebabs += 1

    elif res == "tried_escape":
        if fair_escape_attempts == 0 and games_played == 4:
            fair_escape_attempts += 1
        elif fair_escape_attempts == 1:
            stay("\nCoupbeau : Merci de nous accueillir. Votre foire nous a beaucoup plu. Mais nous devons partir maintenant.")
            stay("Akordd Keyl : Mais, vous ne pouvez toujours pas partir. Vous pouvez continuer de jouer ! Vous devez rester !")
            stay("Vous commencez à marcher vers le portail pour sortir, mais Akordd vous barre la route avec son bras.")
            stay("Akordd Keyl (sérieux) : Je ne peux pas encore vous laisser partir.")
            stay("Vous le regardez perplexes.\nLe piano s'approche d'une grande tente rouge qui se trouve proche de là.")
            stay("Il se retourne vers vous, étend ses bras, et un énorme sourire se dessine sur son visage.")
            stay("Akordd Keyl (avec éloquence) : Mesdames, Messieurs et Mesartéfacts ! Je vous présente mon cousin : Markatt Keyl !")
            stay("La musique de fond s'arrête.")
            stay("Puis, de la fumée commence à s'enfuir de la tente.")
            stay("Soudain, elle éclate entre flammes, desquelles jaillit un claveçorgue monumental et menaçant.")
            stay("Il a deux puissants bras couverts de touches telles des écailles, il traîne des longues et lourdes chaînes,\net ses nombreux tubes crachent des flammes qui s'élèvent jusqu'au ciel.")
            stay("Akordd Keyl : Vous ne sortirez jamais de notre Foire. Vous devez rester jouer, pour toujours !!")
            exe_action(4410)
            won = lancer_combat()
            if won:
                stay("Markatt, vaincu, s'effondre lourdement.")
                stay("Akordd n'est pas en forme non plus. Il tente pourtant de vous séduire à nouveau.\nAkordd : Vous ne devez pas partir !")
                stay("Tu lui réponds qu'ils ont fait de leur Foire une prison;\net que vous devez partir, parce que le plus important vous attend encore.")
                stay("Soudain, Akordd tombe par terre, comme son cousin. Une fumée noire s'échappe de leurs corps et fuit vers les hauteurs.")
                stay("C'était une Ombre !")
                stay("Tu as 3 clés de corruption de Malaxar.")
                INVENTORY.agrandir()
                INVENTORY.ajouter(Touche_clavecorgue)
                stay("Vous sortez enfin de la Foire et reprenez votre mission.")
                aller(profondeurs)

    elif res == "enter_fair":
        stay("Le portail s'ouvre et vous entrez.")
        stay("C'est un clavier de piano placé verticalement, avec deux bras et deux jambes, une cravatte, et une tête sans visage, à l'exception\nd'un sourire éclatant, qui vous accueille.")
        stay("Clavier : Bienvenue, chers voyageurs, à la grandiose Foire des cousins Keyl !")
        stay("Clavier : Et moi, je suis Akordd Keyl.")
        stay("Akordd Keyl : Vous avez jusque-là traversé des épreuves fatiguantes. Venez faire une pause avant de continuer !")
        aller(Foire)

    elif res == "meet_H":
        stay("Vous commencez à marcher vers l'intérieur de la grotte, qui devient de plus en plus sombre.")
        stay("Après avoir marché pendant un moment, vous atteignez enfin le fond, où se trouve une grande cavité\nilluminée seulement par la faible lueur mystique d'une grande masse qui se trouve en son centre.")
        stay("Aussitôt vous entrez, des grands yeux ronds sortent de partout et vous encerclent.")
        stay("Vous êtes face à Hypsiloxis.")
        stay("Celui qui voit tout.")
        stay("Celui qui, selon la légende, un jour, dévorera tout.")
        stay("Vous vous préparez pour vous défendre pendant que des bouches affamées apparaissent aussi autour de vous.")
        stay("Les intenses regards n'ont pas de fond, semblent infinis... Ils brillent avec une couleur d'un autre monde...")
        stay("Tu te rends compte que vous êtes en train d'être hypnotisés !")
        stay("Tu previens les Kapitaines, alors les bouches se lancent aussitôt sur vous.")
        exe_action(7175)
        won = lancer_combat()
        if won:
            exe_action(3573)
            exe_action(8112)
            stay("Hypsiloxis retire ses membres de votre entourage et son immense corps commence à bouger.")
            stay("La masse homogène vous montre son secret.")
            stay("Un énorme oeil, déforme et liquide, apparaît sur son dessus.")
            stay("Une proposition énigmatique, comme venue de nulle part, apparaît dans ta pensée :")
            go_in_H = input("Plonges-tu dans le grand oeil d'Hypsiloxis ?\nTon choix (oui/non): ").lower()
            while go_in_H not in ("oui", "non"):
                go_in_H = input("Sélection invalide.\n\nPlonges-tu dans le grand oeil d'Hypsiloxis ?\nTon choix (oui/non): ").lower()
            if go_in_H == "oui":
                stay("\nTu montes sur le corps de la créature jusqu'à son oeil, qui est plus grand que toi.")
                stay("Tu t'introduis dedans, ce qui fait des petites ondes à la surface.")
                stay("Sa conscience t'enveloppe. Tu rejoins Hypsiloxis.")
                stay("Vos yeux et vos bouches couvrent Malaxar.")
                stay("Puis vous dévorez Malaxar.")
                stay("Malaxar devient Hypsiloxis.")
                run = False
            else:
                stay("\nMalgré l'inexplicable tentation, tu décides de ne pas plonger dans l'oeil d'Hypsiloxis.")
                stay("Alors que vous vous apprêtez à partir, la créature tremble une dernière fois pour laisser s'échapper\nde son corps une obscure émanation qui s'élève et disparaît dans la roche de la montagne au-dessus de vos têtes.")
                stay("C'était un Ombre !")
                stay("Tu as 4 clés de corruption de Malaxar.")
                INVENTORY.agrandir()
                # objet ?
                stay("Vous vous retournez et vous dirigez vers la sortie de l'antre, à la recherche de la dernière Ombre.")
    
    elif res == "walk_in_valley":
        stay("Vous marchez vers les montagnes les plus éloignées, qui sont aussi les plus hautes.")
        stay("Alors que vous traversez la vallée, vous voyez un groupe de personnes s'approcher de vous.")
        stay("Tu les reconnais : c'est Sir Loprex, ton père, et ses gardes.")
        stay("Loprex (très fâché) : Fred ! Qu'est-ce que tu crois que tu fais ? Nous retournons au Fort immédiatement !")
        stay("Loprex (très fâche) : Je t'ai créé pour t'aimer, non pour que tu sois libre !")
        stay("Loprex (très fâché) : Tu m'APPARTIENS !")
        stay("Un sentiment accablant de culpabilité s'empare de toi. Tu acceptes silencieusement et tu commences à marcher vers Loprex.")
        stay("Mais les Kapitaines te retiennent.")
        stay("Zadriel : Qui prétend te réclamer ainsi ?")
        stay("Coupbeau : Nous avons une mission. Ta mission, Fred !")
        stay("Vous refusez de te laisser partir avec Loprex.")
        stay("Loprex (très fâché) : Ce n'était pas une question !")
        exe_action(8383)
        exe_action(7124)
        won = lancer_combat()
        if won:
            exe_action(3922)
            exe_action(1028)
            stay("Vous parvenez à repousser Loprex et ses gardes, affirmant ainsi ta liberté.")
            stay("Loprex : Fred, tu me trahis !")
            stay("Loprex : Je suis ton créateur ! C'est pour moi que tu dois vivre !")
            stay("Tu lui réponds que ton identité est dans tes mains, et non dans les siennes.")
            stay("Tu lui montres que tu es libre et que tu as un propos propre.")
            stay("Loprex s'évanouit sur sa cape rouge avec le symbole de Loprex, et une vapeur noire traverse sa poitrine pour monter vers le ciel.")
            stay("C'était une Ombre !")
            stay("Tu as 5 clés de corruption de Malaxar.")
            INVENTORY.agrandir()
            # objet ?
            stay("Ayant récupéré toutes les clés de corruption de Malaxar, vous partez à la recherche du Grand Noyau.")

    elif res == "reach_sommet_profond":
        PIECE = sommet

    elif res == "go_to_Grand_Noyau":
        stay("Vous marchez sur la montagne jusqu'à atteindre les nuages qui cachent son sommet.")
        stay("La lumière peine à les traverser, vous vous retrouvez dans un milieu sombre.")
        stay("Tu arrives enfin devant une très haute tour, sur laquelle tient une grande sphère.")
        stay("Elle semble contenir en son intérieur des épais nuages noirs qui bougent lentement et qui occultent partiellement une intense splendeur.")
        stay("C'est le Grand Noyau !")
        stay("Tu regardes autour de toi, mais tu ne vois nulle part les Kapitaines.")
        stay("Tu te rapproches alors du Grand Noyau.")
        stay("Une figure obscure se forme à quelques mètres devant toi et bloque ton chemin.")
        stay("Tu l'observes en détail : c'est une copie de toi formée par la brume noire qui vous entoure.")
        stay("Tu te prépares pour le combat, et ta copie fait de même...")
        exe_action(1992)
        exe_action(1325)
        TEAM_FRED = [Fred]
        won = lancer_combat(True)
        if won:
            exe_action(9292)
            stay("C'est alors face au Grand Noyau que tu te trouves.")
            stay("Tu peux le sentir; Malaxar et toi êtes intimement connectés.")
            exe_action(9231)
            exe_action(5347)

    elif res == "free_Malaxar":
        stay("Tu rassembles avec ton âme les 5 clés de corruption et, comme par un acte invisible, tu dégages le Grand Noyau des\nobscurs gaz cosmiques qui le corrompent.")
        stay("Les tâches noires qui couvraient la sphère se dissipent, et elle rayonne alors avec toute sa splendeur.")
        stay("Les nuages qui couvraient le sommet de la montagne disparaissent progressivement, s'offrant alors à toi la vue du large\npaysage de tout Malaxar baignant dans la lumière du Grand Noyau.")
        stay("À tes côtés, les Kapitaines Coupbeau et Zadriel sont réapparus, et vous vous félicitez mutuellement.")
        stay("C'est ainsi que Malaxar, enfin libéré de son ancienne corruption, commence à guérir.")
        stay("Et toi ?")
        stay("Tu es Fred, le frigo, héros de Malaxar.")
        exe_action(1358)
        ended_game = True
        run = False

    return True


def saveAll():
    savePlace()
    saveVars()
    saveInventory()
    saveTeam()
    SAVE.save()

def loadAll():
    SAVE.load()
    loadVars()
    loadPlace()
    loadInventory()
    loadTeam()
    loadActions()


def intro():
    stay("\nDans un fort aux hautes murailles, tu te lèves pour la première fois.")
    stay("La plus importante création de Lord Loprex...")
    stay("Un frigo qui marche.")
    stay("Lord Loprex est le gouverneur du fort Loprex. Il y habite en compagnie des habitants d'un petit village tranquille.")
    stay("Loprex : J'ai travaillé sur toi fort longtemps, Fred !")
    stay("Tu te retournes dans tous les sens, activant tes moteurs au hasard.")
    stay("Loprex : Ah ! Je ne t'ai pas encore appris à marcher.")
    stay("\nQuelques mois plus tard, tu sais déjà te déplacer avec aisance.")
    stay("Un matin tu te lèves et tu regardes par la fenêtre. Les murailles couvrent la vue, mais tu peux voir le village.")
    print("\n----------< INSTRUCTIONS >----------")
    print_tuto()
    stay("")

stay("Il était une fois, dans l'étrange et ancien monde de...")
stay("MALAXAR\n\n")

SAVE = save.selectSavefile()
if SAVE.isNewGame():
    saveone("saved_action_count", saved_action_count)
    saveAll()
    intro()
else:
    loadAll()

myloc()
update()

# main loop
while run:
    recog = False
    COM = clean(command().split(" "))
    if len(COM) > 1:
        COM[1] = " ".join(COM[1:])
        COM = COM[:2]
    assert(len(COM) <= 2)

    if COM[0] in ("aide", "help", "mourir"):
        recog = True
        update()

    elif COM[0] == "danser":
        recog = True
        print("Tu danses.")
        dance_count += 1
        if PIECE == salle_reunion:
            print("Les villageois dansent avec toi.")
        update()

    elif COM[0] == "sortir":
        recog = True
        sortir()

    elif COM[0] == "aller" and len(COM) > 1:
        recog = True
        if PIECE != NoPiece:
            print("Avant tu dois sortir de", PIECE.nom + ".\n")
        else:
            if COM[1] in LIEU.get_cons():
                aller(LIEU.get_by_name(COM[1]))

            elif COM[1] in LIEU.get_pieces():
                entrer(LIEU.get_by_name(COM[1]))

            else:
                aL = alpha_liste(len(LIEU.get_cons()))
                if COM[1].upper() in aL:
                    idx = aL.index(COM[1].upper())
                    aller(LIEU.connexions[idx])

                elif COM[1] in [str(i+1) for i in range(len(LIEU.get_pieces()))]:
                    idx = int(COM[1]) - 1
                    entrer(LIEU.pieces[idx])
                
                else:
                    print("Ce lieu ou cette pièce n'existent pas ou ne sont pas accessibles.\n")

    elif COM[0] == "faire" and len(COM) > 1:
        recog = True
        actions = PIECE.get_actions()
        if COM[1] in [str(i) for i in range(1, len(actions)+1)]:
            idx = int(COM[1]) - 1
            res = PIECE.agir(actions[idx])
            if action_response(res):
                update()
        else:
            print("Cette action n'existe pas !\n")

    elif COM[0] == "stats":
        recog = True
        for member in TEAM_FRED:
            member.print_stats()
        INVENTORY.print_contenu()

    elif COM[0] == "kufyhgfndm":
        recog = True
        update()

    if not recog:
        print("Commande non reconnue. Écris 'aide' ou 'help' pour voir la liste de commandes disponibles.\n")

    saveAll() # autosave!

# FIN
print("\n\nFIN\n")
print("Tu as dansé", dance_count, "fois.")
print("Ton équipe a dévoré", kebabs, "kébab(s).")
print("\nMerci beaucoup d'avoir joué à Fred, ou la Légende de Malaxar !")
print("Ce jeu a pour but de raconter l'histoire de Fred, le frigo.")
print("Tes commentaires, questions et propositions me viendraient en grande aide pour peaufiner le jeu.\nN'hésite donc pas à m'en parler !")
print("\nSincèrement,\nLlorenç G. H.")
stay("\n(Appuie sur Entrée pour sortir.)")