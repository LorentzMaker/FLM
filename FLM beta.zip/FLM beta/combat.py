#FLM

def print_bool(b):
    if type(b) == bool:
        if b is True:
            return "oui"
        return "non"
    return b

class Char():
    def __init__(self, nom, PV, force, defense, seq = None, spectre = False):
        self.nom = nom
        self.maxPV = self.PV = PV
        self.force = force
        self.force_mod = 1
        self.defense = defense
        self.def_mod = 1
        self.shield = 0
        self.abilities = []
        self.seq = seq
        self.seq_idx = 0
        self.effects = {}
        self.spectre = spectre
        
    def damage(self, amount):
        if self.shield > amount:
            self.shield -= amount
        elif self.shield + self.PV <= amount:
            self.shield = 0
            self.PV = 0
        else:
            self.PV -= amount - self.shield
            self.shield = 0

    def attack(self, target, modifier = 1):
        dmg = round(self.force * self.force_mod * modifier)
        if dmg < 0:
            dmg = 0
        target.damage(dmg)
        self.force_mod = 1
        print(self.nom, "attaque", target.nom, "!")
        if target.effect_is("contre-coup", True):
            target.attack(self)
            target.set_effect("contre-coup", False)
        if target.effect_is("surcharge", True):
            target.buff("force", dmg/100)

    def defend(self, modifier = 1):
        if self.PV > 0:
            shd = self.defense * self.def_mod * modifier
            if shd < 0:
                shd = 0
            self.shield += round(shd)
            self.def_mod = 1
            print(self.nom, "se défend.")

    def reset_shield(self):
        self.shield = 0

    def reset_mods(self):
        self.force_mod = 1
        self.def_mod = 1

    def reset_effects(self):
        self.effects = {}

    def reset(self):
        self.reset_shield()
        self.reset_mods()
        self.reset_effects()
        self.PV = self.maxPV
        if self.seq != None:
            self.seq_idx = 0

    def heal(self, amount):
        self.PV += amount
        print(self.nom, "récupère", amount, "PV.")
        if self.PV > self.maxPV:
            self.PV = self.maxPV
        if self.PV < 0:
            self.PV = 0

    def buff(self, st, value):
        print(self.nom, "gagne", f"{round(value*100)}% de", st + ".")
        if st == "force":
            self.force_mod += value
        elif st == "défense":
            self.def_mod += value
        else:
            raise Exception("No such parameter to buff.")
            
    def upgrade(self):
        self.maxPV += round(self.maxPV/10)
        self.force += round(self.force/10)
        self.defense += round(self.defense/10)

    def add_ability(self, ab):
        self.abilities.append(ab)

    def get_ability(self, name):
        for ab in self.abilities:
            if ab.nom == name:
                return ab

    def rm_ability(self, name):
        assert(self.get_ability(name) != None)
        i = 0
        while self.abilities[i].nom != name:
            i += 1
        del self.abilities[i]

    def get_seq(self):
        assert(self.seq != None)
        return self.seq[self.seq_idx]

    def next_seq(self):
        assert(self.seq != None)
        self.seq_idx = (self.seq_idx + 1)%len(self.seq)

    def reset_seq(self):
        assert(self.seq != None)
        self.seq_idx = 0

    def has_effect(self, name):
        return name in self.effects.keys()
    
    def get_effect(self, name):
        if self.has_effect(name):
            return self.effects[name]

    def set_effect(self, name, value):
        self.effects[name] = value

    def rm_effect(self, name):
        if self.has_effect(name):
            del self.effects[name]

    def increase_effect(self, name, amount = 1):
        assert(type(amount) in (int, float))
        if self.has_effect(name):
            assert(type(self.get_effect(name)) in (int, float))
            self.effects[name] += amount
        else:
            self.set_effect(name, amount)

    def effect_is(self, name, value):
        if not self.has_effect(name):
            return False
        return self.get_effect(name) == value

    def print_stats(self):
        print(">>>", self.nom)
        print("PV :", self.PV, "/", self.maxPV)
        print("Bouclier :", self.shield)
        print("Défense :", round(self.defense * self.def_mod))
        print("Force :", round(self.force * self.force_mod))
        if len(self.effects.keys()) == 0:
            print("Effets : (aucun)")
        else:
            print("Effets :")
            for e in self.effects.keys():
                print("\t" + e, ":", print_bool(self.get_effect(e)))
        print()

    def short_stats(self):
        if self.effect_is("stunned", True):
            print(self.nom, "(étourdi)", f": (|{int(self.shield)})", self.PV, "/", self.maxPV)
        else:
            print(self.nom, f": (|{int(self.shield)})", self.PV, "/", self.maxPV)
        print()

class Ability():
    def __init__(self, nom, cout, args, fonc, desc = "", text = ""):
        self.nom = nom
        self.cout = cout
        self.args = args
        self.fonc = fonc
        self.desc = desc
        self.text = text

    def get_desc_text(self):
        if self.desc == "":
            return self.nom + f" [{self.cout}]"
        return self.nom + f" [{self.cout}] : " + self.desc
    
    def print_text(self):
        if self.text != "":
            print(self.text)
            print()
    
    def execute(self, author, args):
        assert(len(args) == len(self.args))
        self.print_text()
        self.fonc(author, args)
