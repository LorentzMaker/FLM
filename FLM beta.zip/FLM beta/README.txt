FRED, OU LA LÉGENDE DE MALAXAR
Auteur : Llorenç G. H.
Date : 4 mai 2025

### Description ###
Dans ce jeu, vous vous mettez dans la "peau" de Fred, qui habite un monde mystique et corrompu appelé Malaxar.
À travers seulement le texte s'affichant sur le terminal, vous interagissez avec d'autres personnages, ou vous
les affrontez en combat, pour dérouler de manière linéaire et interactive cette légendaire histoire.

### Prérequis ###
Vous avez simplement besoin d'avoir Python, en particulier les bibliothèques natives os, random et copy.

### Instructions ###
Pour jouer à ce jeu, vous devez simplement lancer avec Python le fichier "main.py" qui se trouve dans le même
dossier que ce document.
Vos progrès sont automatiquement enregistrés, de sorte que vous pouvez à tout moment arrêter le jeu pour le
continuer plus tard. Pour ceci, il vous suffit de lancer le fichier "main.py" comme la première fois.

Pour assurer le bon fonctionnement de jeu, il est impératif de ne déplacer aucun des fichiers Python, ni le
dossier "savefiles", ou les documents s'y trouvant, qui sera généré lors de la première exécution du jeu.
Il est aussi fortement conseillé de ne pas modifier les fichiers de ce dossier, tant pour éviter son endomma-
gement comme pour vous offrir une expérience véritable du jeu.

### Contact ###
Si vous avez des questions, suggestions, commentaires, voudriez reporter des erreurs ou des bugs, ou avez
besoin d'une réparation technique, je vous invite à vous mettre en contact avec moi directement. Je serai ravi
d'en parler avec vous ou de vous aider le cas échéant.


Amusez-vous !
