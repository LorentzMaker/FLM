# FLM

import os
import copy

extension = ".flm"
dir_name = "savefiles"

def msg(text):
    print(f"Savefile System Message: {text}")

def print_liste(options):
    for i, o in enumerate(options):
        print(f"\t{i}.", o)
    print()

def setupSavefileDir():
    if not os.path.isdir(dir_name):
        os.mkdir(dir_name)
        return True
    return False

def isSavefile(game_name):
    return os.path.exists(os.path.join(dir_name, game_name + extension))

class Savefile():
    def __init__(self, name, new_game = False):
        self.name = name
        self.data = {}
        self.new_game = new_game

    ## File management

    def filename(self):
        return self.name + extension
    
    def filepath(self):
        return os.path.join(dir_name, self.filename())
    
    def exists(self):
        return os.path.exists(self.filepath())
    
    def chname(self, new_name):
        if self.exists():
            os.rename(self.filepath(), os.path.join(dir_name, new_name + extension))
        self.name = new_name
    
    def setup(self):
        if not self.exists():
            setupSavefileDir()
            file = open(self.filepath(), 'w', encoding = "utf8")
            file.close()
            return True
        return False
    
    ## Data management

    def resetData(self):
        self.data = {}

    def isEmpty(self):
        return len(self.data.keys()) == 0

    def setItem(self, key: str, value: str):
        if '=' not in key + value:
            self.data[key] = value
            return True
        return False

    def isItem(self, key):
        return key in self.data.keys()

    def getItem(self, key):
        assert(self.isItem(key))
        return self.data[key]

    def delItem(self, key):
        if self.isItem(key):
            del self.data[key]
            return True
        return False

    # writes into the savefile
    def save(self):
        self.setup()
        file = open(self.filepath(), 'w', encoding = 'utf8')
        for k in self.data.keys():
            file.write(k + '=' + self.data[k] + '\n')
        file.close()

    # reads from the savefile
    def load(self):
        if self.exists():
            file = open(self.filepath(), 'r', encoding = 'utf8')
            lines = [l[:-1].split('=') for l in file.readlines()]
            file.close()
        else:
            lines = []

        self.resetData()
        for k, v in lines:
            self.setItem(k, v)
        return self.data
    
    # checks if the data in the file is the same as the data stored in the savefile object
    def check(self):
        s_data = copy.deepcopy(self.data)
        f_data = self.load()
        return s_data == f_data
    
    def newGame(self):
        self.resetData()
        self.save()
        self.new_game = True

    def isNewGame(self):
        return self.new_game


# returns a savefile object containing the selected game (be it a new game or a loaded one)
def selectSavefile():
    setupSavefileDir()
    files = os.listdir(dir_name)
    savefiles = [f[:-4] for f in files if f[-4:] == ".flm"]
    while True:
        print("Charge un jeu en cours ou commence-en un nouveau :")
        print_liste(["Nouveau jeu"] + savefiles)
        answer = input("Numéro de la sélection : ")

        if answer == "0": # new game selected
            nouveau_jeu = True
            while nouveau_jeu:
                game_name = input("\nNom du nouveau jeu : ")

                if isSavefile(game_name):
                    rew = input("\n/!\\ Un jeu avec ce nom existe déjà. Souhaites-tu le remplacer ? (y/N) ").lower()
                    if rew == 'y':
                        s = Savefile(game_name)
                        s.newGame()
                        print("Nouveau jeu créé.\n")
                        return s
                    else:
                        print("Action annulée.\n")
                        nouveau_jeu = False

                else:
                    s = Savefile(game_name)
                    s.newGame()
                    print("Nouveau jeu créé.\n")
                    return s
        
        elif answer in [str(i+1) for i in range(len(savefiles))]:
            game_name = savefiles[int(answer)-1]
            s = Savefile(game_name, False)
            print("Jeu chargé.\n")
            return s
        
        else:
            print("Sélection invalide.\n")


def encode(value):
    if type(value) == int:
        t = "int"
    elif type(value) == float:
        t = "flt"
    elif type(value) == str:
        t = "str"
    elif type(value) == bool:
        t = "bol"
    elif value == None:
        t = "non"
    else:
        t = "idk"

    return t + str(value)

def decode(text):
    assert(len(text) >= 3)
    t = text[:3]
    v = text[3:]
    if t == "int":
        return int(v)
    elif t == "flt":
        return float(v)
    elif t == "str":
        return v
    elif t == "bol":
        if v == "True":
            return True
        elif v == "False":
            return False
        else:
            raise Exception("Can't be decoded.")
    elif t == "non":
        assert(v == "None")
        return None
    else:
        raise Exception("Can't be decoded.")