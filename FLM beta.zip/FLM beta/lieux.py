#FLM

class sac():
    def __init__(self, espace):
        self.espace = espace
        self.contenu = []

    def get_len(self):
        return len(self.contenu)

    def ajouter(self, objet, msg = True):
        assert(len(self.contenu) <= self.espace) # pour assurer la cohérence

        take = True
        if len(self.contenu) == self.espace:
            if msg:
                print("Tu ne peux pas prendre :", objet.nom, f"({objet.desc}) parce que ton sac est plein.")
            selection = True
            while selection:
                print("Veux-tu remplacer un objet ?")
                print("\t0. Non")
                for i, e in enumerate(self.contenu):
                    print(f"\t{i+1}.", e.nom, f"({e.desc})")
                    
                answer = input("Numéro de la sélection : ")
                if answer in [str(i) for i in range(self.get_len()+1)]:
                    answer = int(answer)
                    if answer == 0:
                        take = False
                    else:
                        del self.contenu[answer-1]
                    selection = False

                else:
                    print("Sélection invalide.\n")

        if take:
            self.contenu.append(objet)
            if msg:
                print("Tu as obtenu :", objet.nom, f"({objet.desc})\n")

    def enlever(self, objet):
        if objet in self.contenu:
            del self.contenu[self.contenu.index(objet)]

    def get_contenu(self):
        return self.contenu

    def agrandir(self, spots = 1):
        assert(spots >= 0)
        self.espace += spots
        print("Ton sac est plus grand.\n")
    
    def print_contenu(self):
        if self.get_len() == 0:
            print("Dans ton sac : (vide)")
        else:
            print("Dans ton sac :")
            for obj in self.contenu:
                print("\t" + obj.nom, f"({obj.desc})")
        print(f"(Tu peux porter jusqu'à {self.espace} objets.)\n")

INVENTORY = sac(3)

ENCYCLOPEDIA = []

class Objet():
    def __init__(self, nom, effet, desc):
        global ENCYCLOPEDIA
        self.nom = nom
        self.effet = effet
        self.desc = desc
        ENCYCLOPEDIA.append(self)
        self.ID = len(ENCYCLOPEDIA)
        self.special = lambda l: None

    def set_special(self, f):
        # f doit prendre un argument une liste uniquement
        self.special = f

def trouverObjet(i):
    ids = [o.ID for o in ENCYCLOPEDIA]
    if i not in ids:
        return None
    return ENCYCLOPEDIA[ids.index(i)]


class piece():
    def __init__(self, nom, actions, desc="", ouvert=True):
        self.nom = nom
        self.lieu = None
        self.actions = actions
        self.act_list = list(self.actions.keys())
        self.desc = desc
        self.ouvert = ouvert

    def get_actions(self):
        return self.act_list
    
    def decrire(self):
        if self.desc != "":
            print(self.desc)
        print()

    def agir(self, act):
        d = self.actions[act]

        if "print" in d.keys():
            print(d["print"])

        if "pickup" in d.keys():
            INVENTORY.ajouter(d["pickup"])

        if "return" in d.keys():
            return d["return"]
        
    def add_action(self, name, dico):
        assert(name not in self.actions.keys())
        self.actions[name] = dico
        self.act_list.append(name)
    
    def mod_action(self, name, dico):
        assert(name in self.actions.keys())
        self.actions[name] = dico

    def rm_action(self, name):
        assert(name in self.actions.keys())
        del self.actions[name]
        del self.act_list[self.act_list.index(name)]
        
    def print_actions(self):
        if len(self.get_actions()) == 0:
            print("Actions possibles : (aucune)")
        else:
            print("Actions possibles :")
            for i, a in enumerate(self.get_actions()):
                print(f"\t{i+1}.", a)
        print()

    def ouvrir(self):
        self.ouvert = not(self.ouvert)

    def printme(self):
        print("---", self.nom, "---")
        self.decrire()
        self.print_actions()


class lieu():
    def __init__(self, nom, pieces, desc=""):
        self.nom = nom
        self.pieces = pieces
        self.connexions = []
        self.desc = desc

    def init_pieces(self):
        for p in self.pieces:
            p.lieu = self

    def get_cons(self):
        return [c.nom.lower() for c in self.connexions]
    
    def get_pieces(self):
        return [p.nom.lower() for p in self.pieces]
    
    def get_by_name(self, name):
        for c in self.connexions:
            if c.nom.lower() == name:
                return c
        for p in self.pieces:
            if p.nom.lower() == name:
                return p
        return None

    def add_con(self, *cons):
        self.connexions += cons

    def decrire(self):
        if self.desc != "":
            print(self.desc)
        print()

    def print_cons(self):
        alph = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

        if len(self.connexions) == 0:
            print("Lieux adjacents : (aucun)")
        else:
            print("Lieux adjacents :")
            for i, c in enumerate(self.connexions):
                print(f"\t{alph[i]}.", c.nom)
        print()

    def print_pieces(self):
        print("Pièces :")
        for i, p in enumerate(self.pieces):
            print(f"\t{i+1}.", p.nom)
        print()

    def printme(self):
        print("####", self.nom, "####")
        self.decrire()
        self.print_pieces()
        self.print_cons()

def connect(*lieux):
    for L in lieux:
        for K in lieux:
            if L != K:
                L.add_con(K)